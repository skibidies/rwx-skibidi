SELECT * FROM x WHERE x.a = (SELECT SUM(y.a) AS a FROM y);
SELECT * FROM x CROSS JOIN (SELECT SUM(y.a) AS a FROM y) AS _u_0 WHERE x.a = _u_0.a;

SELECT * FROM x WHERE x.a IN (SELECT y.a AS a FROM y);
SELECT * FROM x LEFT JOIN (SELECT y.a AS a FROM y GROUP BY y.a) AS _u_0 ON x.a = _u_0.a WHERE NOT _u_0.a IS NULL;

SELECT * FROM x WHERE x.a IN (SELECT y.b AS b FROM y);
SELECT * FROM x LEFT JOIN (SELECT y.b AS b FROM y GROUP BY y.b) AS _u_0 ON x.a = _u_0.b WHERE NOT _u_0.b IS NULL;

SELECT * FROM x WHERE x.a = ANY (SELECT y.a AS a FROM y);
SELECT * FROM x LEFT JOIN (SELECT y.a AS a FROM y GROUP BY y.a) AS _u_0 ON x.a = _u_0.a WHERE NOT _u_0.a IS NULL;

# title: projected IN preserves UNKNOWN
# execute: true
SELECT x.a, x.a IN (SELECT y.b AS b FROM y) AS r FROM x;
SELECT x.a, x.a IN (SELECT y.b AS b FROM y) AS r FROM x;

# title: projected ANY preserves UNKNOWN
# execute: true
SELECT x.a, x.a = ANY (SELECT y.b AS b FROM y) AS r FROM x;
SELECT x.a, x.a = ANY (SELECT y.b AS b FROM y) AS r FROM x;

# title: negated ANY preserves UNKNOWN
# execute: true
SELECT x.a FROM x WHERE NOT (x.a = ANY (SELECT y.b AS b FROM y));
SELECT x.a FROM x WHERE NOT (x.a = ANY (SELECT y.b AS b FROM y));

# title: parenthesized IN conjunct is unnested
# execute: true
SELECT x.a FROM x WHERE x.a > 1 AND ((x.a IN (SELECT y.b AS b FROM y))) ORDER BY x.a;
SELECT x.a FROM x LEFT JOIN (SELECT y.b AS b FROM y GROUP BY y.b) AS _u_0 ON x.a = _u_0.b WHERE x.a > 1 AND ((NOT _u_0.b IS NULL)) ORDER BY x.a;

# title: parenthesized ANY conjunct is unnested
# execute: true
SELECT x.a FROM x WHERE x.a > 1 AND ((x.a = ANY (SELECT y.b AS b FROM y))) ORDER BY x.a;
SELECT x.a FROM x LEFT JOIN (SELECT y.b AS b FROM y GROUP BY y.b) AS _u_0 ON x.a = _u_0.b WHERE x.a > 1 AND ((NOT _u_0.b IS NULL)) ORDER BY x.a;

# title: equality around a different ANY comparison is not a membership predicate
# execute: true
SELECT x.a FROM x WHERE (x.a > ANY (SELECT y.b AS b FROM y)) = FALSE;
SELECT x.a FROM x WHERE (x.a > ANY (SELECT y.b AS b FROM y)) = FALSE;

# title: IN under OR in WHERE is unnested
# execute: true
SELECT x.a FROM x WHERE x.a = 1 OR x.a IN (SELECT y.b AS b FROM y) ORDER BY x.a;
SELECT x.a FROM x LEFT JOIN (SELECT y.b AS b FROM y GROUP BY y.b) AS _u_0 ON x.a = _u_0.b WHERE x.a = 1 OR NOT _u_0.b IS NULL ORDER BY x.a;

SELECT * FROM x WHERE x.a = (SELECT SUM(y.b) AS b FROM y WHERE x.a = y.a);
SELECT * FROM x LEFT JOIN (SELECT SUM(y.b) AS b, y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON x.a = _u_0._u_1 WHERE x.a = _u_0.b;

SELECT * FROM x WHERE x.a > (SELECT SUM(y.b) AS b FROM y WHERE x.a = y.a);
SELECT * FROM x LEFT JOIN (SELECT SUM(y.b) AS b, y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON x.a = _u_0._u_1 WHERE x.a > _u_0.b;

SELECT * FROM x WHERE x.a <> ANY (SELECT y.a AS a FROM y WHERE y.a = x.a);
SELECT * FROM x LEFT JOIN (SELECT y.a AS a FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0.a = x.a WHERE x.a <> _u_0.a;

# title: correlated NOT IN is not unnested because LEFT-JOIN-anti loses three-valued NULL semantics
SELECT * FROM x WHERE x.a NOT IN (SELECT y.a AS a FROM y WHERE y.a = x.a);
SELECT * FROM x WHERE NOT x.a IN (SELECT y.a AS a FROM y WHERE y.a = x.a);

SELECT * FROM x WHERE NOT (x.a IN (SELECT y.a AS a FROM y WHERE y.a = x.a));
SELECT * FROM x WHERE NOT (x.a IN (SELECT y.a AS a FROM y WHERE y.a = x.a));

SELECT * FROM x WHERE x.a IN (SELECT y.a AS a FROM y WHERE y.b = x.a);
SELECT * FROM x LEFT JOIN (SELECT ARRAY_AGG(y.a) AS a, y.b AS _u_1 FROM y WHERE TRUE GROUP BY y.b) AS _u_0 ON _u_0._u_1 = x.a WHERE ARRAY_ANY(_u_0.a, _x -> _x = x.a);

# title: correlated IN in an inner JOIN ON is unnested
# execute: true
SELECT x.a FROM x JOIN x AS x2 ON x.b = x2.b AND x.a IN (SELECT y.b AS b FROM y WHERE y.c = x.a) ORDER BY x.a;
SELECT x.a FROM x LEFT JOIN (SELECT ARRAY_AGG(y.b) AS b, y.c AS _u_1 FROM y WHERE TRUE GROUP BY y.c) AS _u_0 ON _u_0._u_1 = x.a JOIN x AS x2 ON x.b = x2.b AND ARRAY_ANY(_u_0.b, _x -> _x = x.a) ORDER BY x.a;

# title: correlated IN in QUALIFY is unnested
# execute: true
SELECT x.a FROM x QUALIFY ROW_NUMBER() OVER (ORDER BY x.a) > 0 AND x.a IN (SELECT y.b AS b FROM y WHERE y.c = x.a) ORDER BY x.a;
SELECT x.a FROM x LEFT JOIN (SELECT ARRAY_AGG(y.b) AS b, y.c AS _u_1 FROM y WHERE TRUE GROUP BY y.c) AS _u_0 ON _u_0._u_1 = x.a QUALIFY ROW_NUMBER() OVER (ORDER BY x.a) > 0 AND ARRAY_ANY(_u_0.b, _x -> _x = x.a) ORDER BY x.a;

SELECT * FROM x WHERE x.a < (SELECT SUM(y.a) AS a FROM y WHERE y.a = x.a and y.a = x.b and y.b <> x.d);
SELECT * FROM x WHERE x.a < (SELECT SUM(y.a) AS a FROM y WHERE y.a = x.a AND y.a = x.b AND y.b <> x.d);

SELECT * FROM x WHERE EXISTS (SELECT y.a AS a, y.b AS b FROM y WHERE x.a = y.a);
SELECT * FROM x LEFT JOIN (SELECT y.a AS a FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON x.a = _u_0.a WHERE NOT _u_0.a IS NULL;

# title: EXISTS over a scalar aggregate always matches, it returns exactly one row
SELECT * FROM x WHERE EXISTS (SELECT COUNT(*) FROM y WHERE y.a = x.a);
SELECT * FROM x WHERE TRUE;

# title: NOT EXISTS over a scalar aggregate never matches
SELECT * FROM x WHERE NOT EXISTS (SELECT SUM(y.b) FROM y WHERE y.a = x.a);
SELECT * FROM x WHERE NOT TRUE;

# title: EXISTS over a scalar aggregate with a HAVING is not rewritten
SELECT * FROM x WHERE EXISTS (SELECT COUNT(*) FROM y WHERE y.a = x.a HAVING COUNT(*) = 0);
SELECT * FROM x WHERE EXISTS(SELECT COUNT(*) FROM y WHERE y.a = x.a HAVING COUNT(*) = 0);

# title: EXISTS over a scalar aggregate with a FETCH is not rewritten, it can return no rows
SELECT * FROM x WHERE EXISTS (SELECT COUNT(*) FROM y WHERE y.a = x.a FETCH FIRST 0 ROWS ONLY);
SELECT * FROM x WHERE EXISTS(SELECT COUNT(*) FROM y WHERE y.a = x.a FETCH FIRST 0 ROWS ONLY);

# title: EXISTS over a windowed aggregate is not a scalar aggregate
SELECT * FROM x WHERE EXISTS (SELECT COUNT(*) OVER () FROM y WHERE y.a = x.a);
SELECT * FROM x LEFT JOIN (SELECT y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE NOT _u_0._u_1 IS NULL;

# title: EXISTS is not folded when the aggregate belongs to a derived table inside it
SELECT * FROM x WHERE EXISTS (SELECT * FROM (SELECT COUNT(*) AS c FROM y WHERE y.a = x.a) AS t WHERE t.c > 5);
SELECT * FROM x WHERE EXISTS(SELECT * FROM (SELECT COUNT(*) AS c FROM y WHERE y.a = x.a) AS t WHERE t.c > 5);

# title: EXISTS is not folded when the aggregate belongs to a CTE inside it
SELECT * FROM x WHERE EXISTS (WITH t AS (SELECT COUNT(*) AS c FROM y WHERE y.a = x.a) SELECT t.c AS c FROM t WHERE t.c > 5);
SELECT * FROM x WHERE EXISTS(WITH t AS (SELECT COUNT(*) AS c FROM y WHERE y.a = x.a) SELECT t.c AS c FROM t WHERE t.c > 5);

# title: EXISTS is not folded when the aggregate is only one branch of a set operation
SELECT * FROM x WHERE EXISTS (SELECT COUNT(*) AS c FROM y WHERE y.a = x.a INTERSECT SELECT z.a AS a FROM z);
SELECT * FROM x WHERE EXISTS(SELECT COUNT(*) AS c FROM y WHERE y.a = x.a INTERSECT SELECT z.a AS a FROM z);

# title: a correlated branch of a set operation is not decorrelated, it can't be hoisted out
SELECT * FROM x WHERE EXISTS (SELECT y.a AS a FROM y WHERE y.a = x.a INTERSECT SELECT z.a AS a FROM z);
SELECT * FROM x WHERE EXISTS(SELECT y.a AS a FROM y WHERE y.a = x.a INTERSECT SELECT z.a AS a FROM z);

# title: a parenthesized correlated branch of a set operation is not decorrelated either
SELECT * FROM x WHERE EXISTS ((SELECT COUNT(*) AS c FROM y WHERE y.a = x.a) INTERSECT (SELECT z.a AS a FROM z));
SELECT * FROM x WHERE EXISTS((SELECT COUNT(*) AS c FROM y WHERE y.a = x.a) INTERSECT (SELECT z.a AS a FROM z));

SELECT * FROM x WHERE EXISTS ((SELECT y.a AS a FROM y WHERE y.a = x.a) EXCEPT (SELECT z.a AS a FROM z));
SELECT * FROM x WHERE EXISTS((SELECT y.a AS a FROM y WHERE y.a = x.a) EXCEPT (SELECT z.a AS a FROM z));

# title: EXISTS over a scalar aggregate with a QUALIFY is not rewritten
SELECT * FROM x WHERE EXISTS (SELECT COUNT(*) FROM y WHERE y.a = x.a QUALIFY ROW_NUMBER() OVER () = 2);
SELECT * FROM x WHERE EXISTS(SELECT COUNT(*) FROM y WHERE y.a = x.a QUALIFY ROW_NUMBER() OVER () = 2);

# title: an aggregate in a window spec still groups the subquery into a single row
SELECT * FROM x WHERE EXISTS (SELECT RANK() OVER (ORDER BY SUM(y.b)) FROM y WHERE y.a = x.a);
SELECT * FROM x WHERE TRUE;

# title: a parenthesized aggregate in a window spec still groups the subquery
SELECT * FROM x WHERE EXISTS (SELECT RANK() OVER (ORDER BY (SUM(y.b))) FROM y WHERE y.a = x.a);
SELECT * FROM x WHERE TRUE;

# title: an aggregate in the arguments of a windowed function still groups the subquery
SELECT * FROM x WHERE EXISTS (SELECT LAG(SUM(y.b)) OVER (ORDER BY 1) FROM y WHERE y.a = x.a);
SELECT * FROM x WHERE TRUE;

# title: a FILTER between the window and the aggregate leaves it windowed
SELECT * FROM x WHERE EXISTS (SELECT SUM(y.b) FILTER(WHERE y.b > 1) OVER () FROM y WHERE y.a = x.a);
SELECT * FROM x LEFT JOIN (SELECT y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE NOT _u_0._u_1 IS NULL;

# title: EXISTS over a scalar aggregate is folded inside an outer window function
SELECT COUNT(CASE WHEN EXISTS(SELECT COUNT(*) FROM y WHERE y.a = x.a) THEN 1 END) OVER () FROM x;
SELECT COUNT(CASE WHEN TRUE THEN 1 END) OVER () FROM x;

SELECT * FROM x WHERE x.a IN (SELECT y.a AS a FROM y LIMIT 10);
SELECT * FROM x WHERE x.a IN (SELECT y.a AS a FROM y LIMIT 10);

SELECT * FROM x.a WHERE x.a IN (SELECT y.a AS a FROM y OFFSET 10);
SELECT * FROM x.a WHERE x.a IN (SELECT y.a AS a FROM y OFFSET 10);

SELECT * FROM x.a WHERE x.a IN (SELECT y.a AS a, y.b AS b FROM y);
SELECT * FROM x.a WHERE x.a IN (SELECT y.a AS a, y.b AS b FROM y);

SELECT * FROM x.a WHERE x.a > ANY (SELECT y.a FROM y);
SELECT * FROM x.a WHERE x.a > ANY (SELECT y.a FROM y);

SELECT * FROM x WHERE x.a = (SELECT SUM(y.c) AS c FROM y WHERE y.a = x.a LIMIT 10);
SELECT * FROM x WHERE x.a = (SELECT SUM(y.c) AS c FROM y WHERE y.a = x.a LIMIT 10);

SELECT * FROM x WHERE x.a = (SELECT SUM(y.c) AS c FROM y WHERE y.a = x.a OFFSET 10);
SELECT * FROM x WHERE x.a = (SELECT SUM(y.c) AS c FROM y WHERE y.a = x.a OFFSET 10);

SELECT * FROM x WHERE x.a > ALL (SELECT y.c AS c FROM y WHERE y.a = x.a);
SELECT * FROM x LEFT JOIN (SELECT ARRAY_AGG(y.c) AS c, y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE (_u_0.c IS NULL OR ARRAY_ALL(_u_0.c, _x -> x.a > _x));

SELECT * FROM x WHERE x.b > ALL (SELECT y.a AS a FROM y WHERE y.a = x.a);
SELECT * FROM x LEFT JOIN (SELECT y.a AS a FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0.a = x.a WHERE (_u_0.a IS NULL OR x.b > _u_0.a);

SELECT * FROM x WHERE x.a > (SELECT COUNT(*) as d FROM y WHERE y.a = x.a);
SELECT * FROM x LEFT JOIN (SELECT COUNT(*) AS d, y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE x.a > COALESCE(_u_0.d, 0);

# title: invalid statement left alone
SELECT * FROM x WHERE x.a = SUM(SELECT 1);
SELECT * FROM x WHERE x.a = SUM(SELECT 1);

SELECT * FROM x WHERE x.a IN (SELECT max(y.b) AS b FROM y GROUP BY y.a);
SELECT * FROM x LEFT JOIN (SELECT _q.b AS b FROM (SELECT MAX(y.b) AS b FROM y GROUP BY y.a) AS _q GROUP BY _q.b) AS _u_0 ON x.a = _u_0.b WHERE NOT _u_0.b IS NULL;

SELECT x.a > (SELECT SUM(y.a) AS b FROM y) FROM x;
SELECT x.a > _u_0.b FROM x CROSS JOIN (SELECT SUM(y.a) AS b FROM y) AS _u_0;

SELECT (SELECT MAX(t2.c1) AS c1 FROM t2 WHERE t2.c2 = t1.c2 AND t2.c3 <= TRUNC(t1.c3)) AS c FROM t1;
SELECT (SELECT MAX(t2.c1) AS c1 FROM t2 WHERE t2.c2 = t1.c2 AND t2.c3 <= TRUNC(t1.c3)) AS c FROM t1;

SELECT s.t AS t FROM s WHERE 1 IN (SELECT t.a AS a FROM t WHERE t.b > 1);
SELECT s.t AS t FROM s LEFT JOIN (SELECT t.a AS a FROM t WHERE t.b > 1 GROUP BY t.a) AS _u_0 ON 1 = _u_0.a WHERE NOT _u_0.a IS NULL;

# title: can't create GROUP BY clause with an aggregate
SELECT s.t FROM s WHERE 1 IN (SELECT MAX(t.a) AS t1 FROM t);
SELECT s.t FROM s LEFT JOIN (SELECT MAX(t.a) AS t1 FROM t) AS _u_0 ON 1 = _u_0.t1 WHERE NOT _u_0.t1 IS NULL;

# title: can't create GROUP BY clause with an aggregate (nested)
SELECT s.t FROM s WHERE 1 IN (SELECT MAX(t.a) + 1 AS t1 FROM t);
SELECT s.t FROM s LEFT JOIN (SELECT MAX(t.a) + 1 AS t1 FROM t) AS _u_0 ON 1 = _u_0.t1 WHERE NOT _u_0.t1 IS NULL;

SELECT BIT_COUNT(EXISTS(SELECT 1 WHERE FALSE)) AS col FROM t0;
SELECT BIT_COUNT(EXISTS(SELECT 1 WHERE FALSE)) AS col FROM t0;

# title: EXISTS in SELECT with GROUP BY - empty subquery should return 0, not eliminate rows
SELECT EXISTS (SELECT 1 WHERE FALSE) AS ref0 FROM t1, t0 GROUP BY t0.c2;
SELECT EXISTS(SELECT 1 WHERE FALSE) AS ref0 FROM t1, t0 GROUP BY t0.c2;

# title: EXISTS in SELECT with GROUP BY - non-empty subquery should return 1
SELECT EXISTS (SELECT 1 WHERE TRUE) AS ref0 FROM t1, t0 GROUP BY t0.c2;
SELECT EXISTS(SELECT 1 WHERE TRUE) AS ref0 FROM t1, t0 GROUP BY t0.c2;

# title: Multiple EXISTS in SELECT with GROUP BY
SELECT EXISTS (SELECT 1 WHERE FALSE) AS ref0, EXISTS (SELECT 1 WHERE TRUE) AS ref1 FROM t1, t0 GROUP BY t0.c2;
SELECT EXISTS(SELECT 1 WHERE FALSE) AS ref0, EXISTS(SELECT 1 WHERE TRUE) AS ref1 FROM t1, t0 GROUP BY t0.c2;

# title: EXISTS in SELECT with HAVING clause
SELECT EXISTS (SELECT 1 WHERE FALSE) AS ref0 FROM t1 GROUP BY t1.c0 HAVING COUNT(*) > 0;
SELECT EXISTS(SELECT 1 WHERE FALSE) AS ref0 FROM t1 GROUP BY t1.c0 HAVING COUNT(*) > 0;

# title: Skip unnesting GENERATE_SERIES
WITH t2 AS (SELECT CAST(t1.c1 AS BIGINT) AS ref1 FROM GENERATE_SERIES((SELECT MAX(x.a) FROM x AS x), 10, 1) AS t1(c1)) SELECT t2.ref1 AS ref1 FROM t2 AS t2;
WITH t2 AS (SELECT CAST(t1.c1 AS BIGINT) AS ref1 FROM GENERATE_SERIES((SELECT MAX(x.a) FROM x AS x), 10, 1) AS t1(c1)) SELECT t2.ref1 AS ref1 FROM t2 AS t2;

# title: Skip unnesting UNNEST (same issue as GENERATE_SERIES)
WITH t2 AS (SELECT t1.c1 FROM UNNEST((SELECT ARRAY(x.a) FROM x)) AS t1(c1)) SELECT t2.c1 FROM t2;
WITH t2 AS (SELECT t1.c1 FROM UNNEST((SELECT ARRAY(x.a) FROM x)) AS t1(c1)) SELECT t2.c1 FROM t2;

# title: Skip unnesting GENERATE_SERIES but unnesting the rest in the query
SELECT t1.c1 > (SELECT SUM(y.a) AS b FROM y) FROM x JOIN GENERATE_SERIES((SELECT MAX(x.a) FROM x AS x), 10, 1) AS t1(c1) ON t1.c1 > x.a;
SELECT t1.c1 > _u_0.b FROM x JOIN GENERATE_SERIES((SELECT MAX(x.a) FROM x AS x), 10, 1) AS t1(c1) ON t1.c1 > x.a CROSS JOIN (SELECT SUM(y.a) AS b FROM y) AS _u_0;

# title: correlated scalar subquery with EQ + range predicates inside a function in SELECT should not crash (issue #7295)
SELECT COALESCE((SELECT MAX(b.val) FROM t b WHERE b.val < a.val AND b.id = a.id), a.val) AS result FROM t a;
SELECT COALESCE((SELECT MAX(b.val) FROM t AS b WHERE b.val < a.val AND b.id = a.id), a.val) AS result FROM t AS a;

# title: IN with UNION ALL subquery should use derived alias in wrapper SELECT
SELECT * FROM x WHERE x.a IN (SELECT y.a AS a FROM y UNION ALL SELECT z.a AS a FROM z);
SELECT * FROM x LEFT JOIN (SELECT _u_0.a AS a FROM (SELECT y.a AS a FROM y UNION ALL SELECT z.a AS a FROM z) AS _u_0 GROUP BY _u_0.a) AS _u_1 ON x.a = _u_1.a WHERE NOT _u_1.a IS NULL;

# title: NOT IN is not unnested because LEFT-JOIN-anti loses three-valued NULL semantics
SELECT * FROM x WHERE x.a NOT IN (SELECT y.a AS a FROM y);
SELECT * FROM x WHERE NOT x.a IN (SELECT y.a AS a FROM y);

SELECT * FROM x WHERE NOT (x.a IN (SELECT y.a AS a FROM y));
SELECT * FROM x WHERE NOT (x.a IN (SELECT y.a AS a FROM y));

# title: NOT IN with UNION ALL subquery is not unnested
SELECT * FROM x WHERE x.a NOT IN (SELECT y.a AS a FROM y UNION ALL SELECT z.a AS a FROM z);
SELECT * FROM x WHERE NOT x.a IN (SELECT y.a AS a FROM y UNION ALL SELECT z.a AS a FROM z);

# title: correlated EXISTS with negated equality is not unnested
SELECT x.id FROM x WHERE EXISTS (SELECT 1 FROM y WHERE NOT (y.id = x.id));
SELECT x.id FROM x WHERE EXISTS(SELECT 1 FROM y WHERE NOT (y.id = x.id));

# title: correlated NOT EXISTS with negated equality is not unnested
SELECT x.id FROM x WHERE NOT EXISTS (SELECT 1 FROM y WHERE NOT (y.id = x.id));
SELECT x.id FROM x WHERE NOT EXISTS(SELECT 1 FROM y WHERE NOT (y.id = x.id));

# title: positive equality with NOT operand is unnested
SELECT x.flag FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.flag = (NOT x.flag));
SELECT x.flag FROM x LEFT JOIN (SELECT y.flag AS _u_1 FROM y WHERE TRUE GROUP BY y.flag) AS _u_0 ON _u_0._u_1 = (NOT x.flag) WHERE NOT _u_0._u_1 IS NULL;

# title: exists with a single non-equality key is unnested
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a AND y.b > x.b);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1, ARRAY_AGG(y.b) AS _u_2 FROM y WHERE TRUE AND TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE (NOT _u_0._u_1 IS NULL AND ARRAY_ANY(_u_0._u_2, _x -> _x > x.b));

# title: exists with multiple non-equality keys pairs them in a struct
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a AND y.b > x.b AND y.c < x.c);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1, ARRAY_AGG(STRUCT(y.b AS _u_2, y.c AS _u_3)) AS _u_4 FROM y WHERE TRUE AND TRUE AND TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE (NOT _u_0._u_1 IS NULL AND ARRAY_ANY(_u_0._u_4, _x -> _x._u_2 > x.b AND _x._u_3 < x.c));

# title: in with a non-equality key is not unnested
SELECT x.a FROM x WHERE x.c IN (SELECT y.c FROM y WHERE y.a = x.a AND y.b > x.b);
SELECT x.a FROM x WHERE x.c IN (SELECT y.c FROM y WHERE y.a = x.a AND y.b > x.b);

# title: exists with multiple non-equality predicates on the same key
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a AND y.b > x.b AND y.b < x.c);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1, ARRAY_AGG(y.b) AS _u_2 FROM y WHERE TRUE AND TRUE AND TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE (NOT _u_0._u_1 IS NULL AND ARRAY_ANY(_u_0._u_2, _x -> _x > x.b AND _x < x.c));

# title: exists with a non-equality key that is also the projected value
SELECT x.a FROM x WHERE EXISTS (SELECT y.b AS b FROM y WHERE y.a = x.a AND y.b > x.b);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1, ARRAY_AGG(y.b) AS _u_2 FROM y WHERE TRUE AND TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE (NOT _u_0._u_1 IS NULL AND ARRAY_ANY(_u_0._u_2, _x -> _x > x.b));

# title: exists with a non-equality predicate on an equality key checks it on the join
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a AND y.a > x.c);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1 FROM y WHERE TRUE AND TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a AND _u_0._u_1 > x.c WHERE NOT _u_0._u_1 IS NULL;

# title: predicate with an inner column on the outer side is not unnested
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a AND y.b > x.b + y.c);
SELECT x.a FROM x WHERE EXISTS(SELECT 1 FROM y WHERE y.a = x.a AND y.b > x.b + y.c);

# title: predicate with an outer column on the key side is not unnested
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a + x.b = x.a);
SELECT x.a FROM x WHERE EXISTS(SELECT 1 FROM y WHERE y.a + x.b = x.a);

# title: exists with a group by drops it so that the join stays unique on its keys
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a GROUP BY y.c);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE NOT _u_0._u_1 IS NULL;

# title: not exists with a group by
SELECT x.a FROM x WHERE NOT EXISTS (SELECT 1 FROM y WHERE y.a = x.a GROUP BY y.c);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE NOT NOT _u_0._u_1 IS NULL;

# title: exists with an aggregate projection and a group by is not always true
SELECT x.a FROM x WHERE EXISTS (SELECT COUNT(*) FROM y WHERE y.a = x.a GROUP BY y.c);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE NOT _u_0._u_1 IS NULL;

# title: exists with distinct drops it
SELECT x.a FROM x WHERE EXISTS (SELECT DISTINCT y.c FROM y WHERE y.a = x.a);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE NOT _u_0._u_1 IS NULL;

# title: exists with an order by drops it
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a ORDER BY y.c);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE NOT _u_0._u_1 IS NULL;

# title: exists with a group by and having is not unnested
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a GROUP BY y.c HAVING COUNT(*) > 1);
SELECT x.a FROM x WHERE EXISTS(SELECT 1 FROM y WHERE y.a = x.a GROUP BY y.c HAVING COUNT(*) > 1);

# title: exists with a group by and qualify is not unnested
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a GROUP BY y.c QUALIFY ROW_NUMBER() OVER (ORDER BY y.c) = 1);
SELECT x.a FROM x WHERE EXISTS(SELECT 1 FROM y WHERE y.a = x.a GROUP BY y.c QUALIFY ROW_NUMBER() OVER (ORDER BY y.c) = 1);

# title: exists with a non-equality key and having is not unnested
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a AND y.b > x.b GROUP BY y.a HAVING COUNT(*) > 1);
SELECT x.a FROM x WHERE EXISTS(SELECT 1 FROM y WHERE y.a = x.a AND y.b > x.b GROUP BY y.a HAVING COUNT(*) > 1);

# title: exists with a rollup is not unnested since it returns a row even for empty input
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a GROUP BY ROLLUP (y.c));
SELECT x.a FROM x WHERE EXISTS(SELECT 1 FROM y WHERE y.a = x.a GROUP BY ROLLUP (y.c));

# title: exists with an empty grouping set is not unnested
SELECT x.a FROM x WHERE EXISTS (SELECT 1 FROM y WHERE y.a = x.a GROUP BY ());
SELECT x.a FROM x WHERE EXISTS(SELECT 1 FROM y WHERE y.a = x.a GROUP BY ());

# title: exists with group by all and only aggregate projections is always true
SELECT x.a FROM x WHERE EXISTS (SELECT COUNT(*) FROM y WHERE y.a = x.a GROUP BY ALL);
SELECT x.a FROM x WHERE TRUE;

# title: exists with group by all and only windowed aggregate projections is a row check
SELECT x.a FROM x WHERE EXISTS (SELECT COUNT(*) OVER () FROM y WHERE y.a = x.a GROUP BY ALL);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE NOT _u_0._u_1 IS NULL;

# title: exists with group by all and a non-aggregate projection drops it
SELECT x.a FROM x WHERE EXISTS (SELECT y.c, COUNT(*) FROM y WHERE y.a = x.a GROUP BY ALL);
SELECT x.a FROM x LEFT JOIN (SELECT y.a AS _u_1 FROM y WHERE TRUE GROUP BY y.a) AS _u_0 ON _u_0._u_1 = x.a WHERE NOT _u_0._u_1 IS NULL;

# title: preserve IN in LEFT JOIN ON
# execute: true
SELECT x.a FROM x LEFT JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2);
SELECT x.a FROM x LEFT JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2);

# title: preserve IN in RIGHT JOIN ON
# execute: true
# execute_min_python: 3.11
SELECT x.a FROM x RIGHT JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2);
SELECT x.a FROM x RIGHT JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2);

# title: preserve IN in FULL JOIN ON
# execute: true
# execute_min_python: 3.11
SELECT x.a FROM x FULL JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2);
SELECT x.a FROM x FULL JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2);

# title: preserve IN in SEMI JOIN ON
# execute: true
# execute_min_python: 3.10
SELECT x.a FROM x SEMI JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2);
SELECT x.a FROM x SEMI JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2);

# title: preserve IN in ANTI JOIN ON
# execute: true
# execute_min_python: 3.10
SELECT x.a FROM x ANTI JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2);
SELECT x.a FROM x ANTI JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2);

# title: preserve IN under OR in JOIN ON
# execute: true
SELECT x.a FROM x JOIN y ON x.a = y.b OR y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b > 100);
SELECT x.a FROM x JOIN y ON x.a = y.b OR y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b > 100);

# title: preserve ANY under NOT in JOIN ON
# execute: true
SELECT x.a FROM x JOIN y ON NOT (y.b = ANY (SELECT z.b AS b FROM y AS z WHERE z.b > 100));
SELECT x.a FROM x JOIN y ON NOT (y.b = ANY (SELECT z.b AS b FROM y AS z WHERE z.b > 100));

# title: unnest parenthesized IN conjunct in INNER JOIN ON
# execute: true
SELECT x.a FROM x INNER JOIN y ON x.a = y.b AND (y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2));
SELECT x.a FROM x INNER JOIN y ON x.a = y.b AND (TRUE) LEFT JOIN (SELECT z.b AS b FROM y AS z WHERE z.b = 2 GROUP BY z.b) AS _u_0 ON y.b = _u_0.b WHERE NOT _u_0.b IS NULL;

# title: unnest ANY conjunct in JOIN ON
# execute: true
SELECT x.a FROM x JOIN y ON x.a = y.b AND y.b = ANY (SELECT z.b AS b FROM y AS z WHERE z.b = 2);
SELECT x.a FROM x JOIN y ON x.a = y.b AND TRUE LEFT JOIN (SELECT z.b AS b FROM y AS z WHERE z.b = 2 GROUP BY z.b) AS _u_0 ON y.b = _u_0.b WHERE NOT _u_0.b IS NULL;

# title: preserve uncorrelated scalar subquery in LEFT JOIN ON
# execute: true
SELECT x.a FROM x LEFT JOIN y ON y.b = (SELECT MAX(z.b) AS b FROM y AS z);
SELECT x.a FROM x LEFT JOIN y ON y.b = (SELECT MAX(z.b) AS b FROM y AS z);

# title: preserve correlated scalar subquery in LEFT JOIN ON
# execute: true
SELECT x.a FROM x LEFT JOIN y ON y.b = (SELECT MAX(z.b) AS b FROM y AS z WHERE z.b = x.a);
SELECT x.a FROM x LEFT JOIN y ON y.b = (SELECT MAX(z.b) AS b FROM y AS z WHERE z.b = x.a);

# title: preserve correlation to the right source in JOIN ON
# execute: true
SELECT x.a FROM x JOIN y ON x.a = (SELECT MAX(z.b) AS b FROM y AS z WHERE z.b = y.b);
SELECT x.a FROM x JOIN y ON x.a = (SELECT MAX(z.b) AS b FROM y AS z WHERE z.b = y.b);

# title: decorrelate left source before its use in JOIN ON
# execute: true
SELECT x.a FROM x JOIN y ON y.b = (SELECT MAX(z.b) AS b FROM y AS z WHERE z.b = x.a) ORDER BY x.a;
SELECT x.a FROM x LEFT JOIN (SELECT MAX(z.b) AS b, z.b AS _u_1 FROM y AS z WHERE TRUE GROUP BY z.b) AS _u_0 ON _u_0._u_1 = x.a JOIN y ON y.b = _u_0.b ORDER BY x.a;

# title: preserve IN in JOIN ON before a RIGHT JOIN
# execute: true
SELECT x.a, w.d FROM x JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2) RIGHT JOIN w ON FALSE;
SELECT x.a, w.d FROM x JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2) RIGHT JOIN w ON FALSE;

# title: preserve IN in JOIN ON before a FULL JOIN
# execute: true
SELECT x.a, w.d FROM x JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2) FULL JOIN w ON FALSE;
SELECT x.a, w.d FROM x JOIN y ON x.a = y.b AND y.b IN (SELECT z.b AS b FROM y AS z WHERE z.b = 2) FULL JOIN w ON FALSE;

# title: Scalar subquery inside an aggregate CASE
# execute: true
SELECT SUM(CASE WHEN x.a = (SELECT MAX(y.b) AS b FROM y WHERE y.b = 2) THEN 1 ELSE 0 END) AS total FROM x;
SELECT SUM(CASE WHEN x.a = _u_0.b THEN 1 ELSE 0 END) AS total FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y WHERE y.b = 2) AS _u_0;

# title: Scalar subquery inside an aggregate with GROUP BY
# execute: true
SELECT x.b, SUM(CASE WHEN x.a = (SELECT MAX(y.b) AS b FROM y WHERE y.b = 2) THEN 1 ELSE 0 END) AS total FROM x GROUP BY x.b ORDER BY x.b;
SELECT x.b, SUM(CASE WHEN x.a = _u_0.b THEN 1 ELSE 0 END) AS total FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y WHERE y.b = 2) AS _u_0 GROUP BY x.b ORDER BY x.b;

# title: Scalar subquery as a direct aggregate argument
# execute: true
SELECT SUM((SELECT MAX(y.b) AS b FROM y)) AS total FROM x;
SELECT SUM(_u_0.b) AS total FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0;

# title: Scalar subquery inside a HAVING aggregate
# execute: true
SELECT x.b FROM x GROUP BY x.b HAVING SUM(CASE WHEN x.a = (SELECT MAX(y.b) AS b FROM y WHERE y.b = 2) THEN 1 ELSE 0 END) > 0;
SELECT x.b FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y WHERE y.b = 2) AS _u_0 GROUP BY x.b HAVING SUM(CASE WHEN x.a = _u_0.b THEN 1 ELSE 0 END) > 0;

# title: EXISTS inside an aggregate
# execute: true
SELECT SUM(CASE WHEN EXISTS(SELECT 1 AS a WHERE FALSE) THEN 1 ELSE 0 END) AS total FROM x;
SELECT SUM(CASE WHEN EXISTS(SELECT 1 AS a WHERE FALSE) THEN 1 ELSE 0 END) AS total FROM x;

# title: Scalar subquery outside an aggregate
# execute: true
SELECT SUM(x.a) + (SELECT MAX(y.b) AS b FROM y) AS total FROM x;
SELECT SUM(x.a) + MAX(_u_0.b) AS total FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0;

# title: Scalar subquery in WHERE before aggregation
# execute: true
SELECT SUM(x.a) AS total FROM x WHERE x.a = (SELECT MAX(y.b) AS b FROM y);
SELECT SUM(x.a) AS total FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0 WHERE x.a = _u_0.b;

# title: Scalar subquery outside a HAVING aggregate
# execute: true
SELECT x.b FROM x GROUP BY x.b HAVING SUM(x.a) > (SELECT MAX(y.b) AS b FROM y) ORDER BY x.b;
SELECT x.b FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0 GROUP BY x.b HAVING SUM(x.a) > MAX(_u_0.b) ORDER BY x.b;

# title: Aggregate ancestor search stops at the current query
# execute: true
SELECT SUM((SELECT SUM(y.b) + (SELECT MAX(z.b) AS b FROM y AS z) AS b FROM y)) AS total FROM x;
SELECT SUM(_u_1.b) AS total FROM x CROSS JOIN (SELECT SUM(y.b) + MAX(_u_0.b) AS b FROM y CROSS JOIN (SELECT MAX(z.b) AS b FROM y AS z) AS _u_0) AS _u_1;

# title: Scalar subquery inside a window aggregate over grouped rows
# execute: true
SELECT x.b, SUM((SELECT MAX(y.b) AS b FROM y)) OVER () AS total FROM x GROUP BY x.b ORDER BY x.b;
SELECT x.b, SUM(MAX(_u_0.b)) OVER () AS total FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0 GROUP BY x.b ORDER BY x.b;

# title: Scalar subquery inside a filtered window aggregate over grouped rows
# execute: true
SELECT x.b, SUM((SELECT MAX(y.b) AS b FROM y)) FILTER(WHERE x.b > 1) OVER () AS total FROM x GROUP BY x.b ORDER BY x.b;
SELECT x.b, SUM(MAX(_u_0.b)) FILTER(WHERE x.b > 1) OVER () AS total FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0 GROUP BY x.b ORDER BY x.b;

# title: Scalar subquery inside a grouped aggregate within a window aggregate
# execute: true
SELECT x.b, SUM(SUM((SELECT MAX(y.b) AS b FROM y))) OVER () AS total FROM x GROUP BY x.b ORDER BY x.b;
SELECT x.b, SUM(SUM(_u_0.b)) OVER () AS total FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0 GROUP BY x.b ORDER BY x.b;

# title: Scalar subquery inside a window ordering aggregate
# execute: true
SELECT x.b, ROW_NUMBER() OVER (ORDER BY SUM((SELECT MAX(y.b) AS b FROM y)), x.b) AS n FROM x GROUP BY x.b ORDER BY x.b;
SELECT x.b, ROW_NUMBER() OVER (ORDER BY SUM(_u_0.b), x.b) AS n FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0 GROUP BY x.b ORDER BY x.b;

# title: Scalar subquery inside a WITHIN GROUP window aggregate
# execute: true
SELECT x.b, ARRAY_AGG((SELECT MAX(y.b) AS b FROM y)) WITHIN GROUP (ORDER BY x.b) OVER () AS a FROM x GROUP BY x.b ORDER BY x.b;
SELECT x.b, ARRAY_AGG(MAX(_u_0.b)) WITHIN GROUP (ORDER BY x.b) OVER () AS a FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0 GROUP BY x.b ORDER BY x.b;

# title: Scalar subquery inside a window partitioning aggregate
# execute: true
SELECT x.b, ROW_NUMBER() OVER (PARTITION BY SUM((SELECT MAX(y.b) AS b FROM y)) ORDER BY x.b) AS n FROM x GROUP BY x.b ORDER BY x.b;
SELECT x.b, ROW_NUMBER() OVER (PARTITION BY SUM(_u_0.b) ORDER BY x.b) AS n FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0 GROUP BY x.b ORDER BY x.b;

# title: Aggregate ancestor traversal stops at a CTE query
# execute: true
WITH q AS (SELECT SUM(x.a) + (SELECT MAX(y.b) AS b FROM y) AS total FROM x) SELECT q.total FROM q;
WITH q AS (SELECT SUM(x.a) + MAX(_u_0.b) AS total FROM x CROSS JOIN (SELECT MAX(y.b) AS b FROM y) AS _u_0) SELECT q.total FROM q;

# title: Preserve a scalar subquery with an anonymous aggregate only in HAVING
# execute: true
SELECT 1 + (SELECT COUNT(*) AS n FROM y) AS n FROM x HAVING FAVG(x.a) > 0;
SELECT 1 + (SELECT COUNT(*) AS n FROM y) AS n FROM x HAVING FAVG(x.a) > 0;

# title: Preserve a scalar subquery with an anonymous aggregate only in ORDER BY
# execute: true
SELECT 1 + (SELECT COUNT(*) AS n FROM y) AS n FROM x ORDER BY FAVG(x.a);
SELECT 1 + (SELECT COUNT(*) AS n FROM y) AS n FROM x ORDER BY FAVG(x.a);

# title: Preserve a scalar subquery with an anonymous aggregate only in QUALIFY
# execute: true
SELECT 1 + (SELECT COUNT(*) AS n FROM y) AS n, ROW_NUMBER() OVER () AS rn FROM x QUALIFY FAVG(x.a) > 0;
SELECT 1 + (SELECT COUNT(*) AS n FROM y) AS n, ROW_NUMBER() OVER () AS rn FROM x QUALIFY FAVG(x.a) > 0;

# title: Explicit grouping permits hoisting with an anonymous aggregate in HAVING
# execute: true
SELECT x.a, 1 + (SELECT COUNT(*) AS n FROM y) AS n FROM x GROUP BY x.a HAVING FAVG(x.a) > 0 ORDER BY x.a;
SELECT x.a, 1 + MAX(_u_0.n) AS n FROM x CROSS JOIN (SELECT COUNT(*) AS n FROM y) AS _u_0 GROUP BY x.a HAVING FAVG(x.a) > 0 ORDER BY x.a;

# title: Anonymous function search in ORDER BY stops at a nested query
# execute: true
SELECT 1 + (SELECT COUNT(*) AS n FROM y) AS n FROM x ORDER BY (SELECT FAVG(y.b) FROM y);
SELECT 1 + _u_0.n AS n FROM x CROSS JOIN (SELECT COUNT(*) AS n FROM y) AS _u_0 ORDER BY (SELECT FAVG(y.b) FROM y);

# title: Anonymous scalar functions in WHERE permit hoisting
# execute: true
SELECT 1 + (SELECT COUNT(*) AS n FROM y) AS n FROM x WHERE EVEN(x.a) > 0;
SELECT 1 + _u_0.n AS n FROM x CROSS JOIN (SELECT COUNT(*) AS n FROM y) AS _u_0 WHERE EVEN(x.a) > 0;

# title: Correlated IS NULL predicate in EXISTS is not rewritten
# execute: true
SELECT * FROM x WHERE EXISTS (SELECT y.b AS b FROM y WHERE y.b = x.a AND x.b IS NULL);
SELECT * FROM x WHERE EXISTS(SELECT y.b AS b FROM y WHERE y.b = x.a AND x.b IS NULL);
