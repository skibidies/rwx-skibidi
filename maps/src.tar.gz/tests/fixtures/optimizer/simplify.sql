--------------------------------------
-- Conditions
--------------------------------------
x AND x;
x AND TRUE;

y OR y;
y AND TRUE;

x AND NOT x;
NOT x AND x;

x OR NOT x;
NOT x OR x;

-- unlike a bare column, a predicate known to be non-null is eliminated by its complement
# dialect: postgres
'abc' ~ 'a' AND NOT 'abc' ~ 'a';
FALSE;

# dialect: postgres
'abc' ~ 'a' OR NOT 'abc' ~ 'a';
TRUE;

1 AND TRUE;
TRUE;

TRUE AND TRUE;
TRUE;

1 AND TRUE AND 1 AND 1;
TRUE;

TRUE AND FALSE;
FALSE;

FALSE AND FALSE;
FALSE;

FALSE AND TRUE AND TRUE;
FALSE;

x > y OR FALSE;
x > y;

FALSE OR x = y;
x = y;

1 = 1;
TRUE;

1.0 = 1;
TRUE;

CAST('2023-01-01' AS DATE) = CAST('2023-01-01' AS DATE);
TRUE;

'x' = 'y';
FALSE;

'x' = 'x';
TRUE;

STRUCT(NULL AS a);
STRUCT(NULL AS a);

NULL AND TRUE;
NULL AND TRUE;

NULL AND FALSE;
FALSE;

NULL AND NULL;
NULL AND TRUE;

NULL OR TRUE;
TRUE;

NULL OR NULL;
NULL AND TRUE;

FALSE OR NULL;
NULL AND TRUE;

NOT TRUE;
FALSE;

NOT FALSE;
TRUE;

NOT NULL;
NULL AND TRUE;

-- the NULL-condition rewrite must be parenthesized under NOT or a different connector
NOT NOT NULL;
NULL AND TRUE;

x = 1 OR NOT NOT NULL;
NULL OR x = 1;

x = 1 AND NOT NOT NULL;
NULL AND x = 1;

NULL = NULL;
NULL = NULL;

SELECT (EXISTS(SELECT 1 WHERE FALSE)) AND NULL;
SELECT EXISTS(SELECT 1 WHERE FALSE) AND NULL;

SELECT NULL AND (EXISTS(SELECT 1 WHERE FALSE));
SELECT EXISTS(SELECT 1 WHERE FALSE) AND NULL;

1 AND 0;
FALSE;

0 AND 1;
FALSE;

0 OR 1;
TRUE;

0 OR NULL;
NULL AND TRUE;

NULL OR 0;
NULL AND TRUE;

0 AND NULL;
FALSE;

NULL AND 0;
FALSE;

-- Can't optimize this because different engines do different things
-- mysql converts to 0 and 1 but tsql does true and false
NULL <=> NULL;
NULL IS NOT DISTINCT FROM NULL;

a IS NOT DISTINCT FROM a;
a IS NOT DISTINCT FROM a;

NULL IS DISTINCT FROM NULL;
NULL IS DISTINCT FROM NULL;

NOT (NOT TRUE);
TRUE;

NOT (a = b);
a <> b;

# dialect: duckdb
# execute: true
SELECT c = NOT (a = b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c = (a <> b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c = NOT (a <> b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c = (a = b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c = NOT (a < b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c = (a >= b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c = NOT (a <= b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c = (a > b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c = NOT (a > b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c = (a <= b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c = NOT (a >= b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c = (a < b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c <> NOT (a = b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c <> (a <> b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c <> NOT (a <> b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c <> (a = b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c <> NOT (a < b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c <> (a >= b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c <> NOT (a <= b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c <> (a > b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c <> NOT (a > b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c <> (a <= b) AS result FROM comparisons ORDER BY a, b, c;

# dialect: duckdb
# execute: true
SELECT c <> NOT (a >= b) AS result FROM comparisons ORDER BY a, b, c;
SELECT c <> (a < b) AS result FROM comparisons ORDER BY a, b, c;

1 - NOT (b = b);
1 - (b <> b);

2 || NOT (b = 2);
2 || (b <> 2);

SELECT c = NOT (a = ALL (SELECT b FROM t)) FROM t;
SELECT c = (a <> ANY(SELECT b FROM t)) FROM t;

SELECT c = NOT (a <> ANY (SELECT b FROM t)) FROM t;
SELECT c = (a = ALL ((SELECT b FROM t))) FROM t;

a AND (b OR b);
a AND b;

a AND (b AND b);
a AND b;

-- bigquery doesn't allow unparenthesis comparisons
(x is not null) != (y is null);
(NOT x IS NULL) <> (y IS NULL);

# dialect: mysql
A XOR A;
A XOR A;

# dialect: mysql
TRUE XOR FALSE AND FALSE;
FALSE XOR TRUE;

# dialect: mysql
TRUE OR TRUE XOR TRUE;
TRUE;

# dialect: mysql
SELECT DISTINCT GREATEST(EXISTS(SELECT 1 WHERE FALSE), (EXISTS(SELECT 1 WHERE FALSE)) XOR ((0.08) IN ((t1.c0) XOR (t1.c0)))) AS ref0 FROM (SELECT NULL AS c0 UNION ALL SELECT 1 AS c0) AS t1, (SELECT 0.01 AS c1) AS t0;
SELECT DISTINCT GREATEST(EXISTS(SELECT 1 WHERE FALSE), 0.08 IN (t1.c0 XOR t1.c0) XOR EXISTS(SELECT 1 WHERE FALSE)) AS ref0 FROM (SELECT NULL AS c0 UNION ALL SELECT 1 AS c0) AS t1, (SELECT 0.01 AS c1) AS t0;

TRUE AND TRUE OR TRUE AND FALSE;
TRUE;

COALESCE(x, y) <> ALL (SELECT z FROM w);
COALESCE(x, y) <> ALL (SELECT z FROM w);

SELECT NOT (2 <> ALL (SELECT 2 UNION ALL SELECT 3));
SELECT 2 = ANY(SELECT 2 UNION ALL SELECT 3);

SELECT t_bool.a AND TRUE FROM t_bool;
SELECT t_bool.a FROM t_bool;

SELECT TRUE AND t_bool.a FROM t_bool;
SELECT t_bool.a FROM t_bool;

SELECT t_bool.a OR FALSE FROM t_bool;
SELECT t_bool.a FROM t_bool;

SELECT FALSE OR t_bool.a FROM t_bool;
SELECT t_bool.a FROM t_bool;

--------------------------------------
-- Absorption
--------------------------------------
(A OR B) AND (C OR NOT A);
(A OR B) AND (C OR NOT A);

A AND (A OR B);
A AND TRUE;

A AND D AND E AND (B OR A);
A AND D AND E;

D AND A AND E AND (B OR A);
A AND D AND E;

(A OR B) AND A;
A AND TRUE;

C AND D AND (A OR B) AND E AND F AND A;
A AND C AND D AND E AND F;

A OR (A AND B);
A AND TRUE;

(A AND B) OR A;
A AND TRUE;

A AND (NOT A OR B);
A AND (B OR NOT A);

(NOT A OR B) AND A;
A AND (B OR NOT A);

A OR (NOT A AND B);
A OR (B AND NOT A);

A OR ((((NOT A AND B))));
A OR (B AND NOT A);

x IS NULL AND (NOT (x IS NULL) OR B);
B AND x IS NULL;

x IS NULL OR (NOT (x IS NULL) AND B);
B OR x IS NULL;

x NOT LIKE 'a%' OR (y IN (1, 2) AND x LIKE 'a%');
(x LIKE 'a%' AND y IN (1, 2)) OR x NOT LIKE 'a%';

x NOT ILIKE 'a%' OR (y IN (1, 2) AND x ILIKE 'a%');
(x ILIKE 'a%' AND y IN (1, 2)) OR x NOT ILIKE 'a%';

(A OR C) AND ((A OR C) OR B);
A OR C;

(A OR C) AND (A OR B OR C);
A OR C;

A AND (B AND C) AND (D AND E);
A AND B AND C AND D AND E;

A AND (A OR B) AND (A OR B OR C);
A AND TRUE;

(A OR B) AND (A OR C) AND (A OR B OR C);
(A OR B) AND (A OR C);

# dialect: clickhouse
SELECT t_bool.a AND (NOT t_bool.a OR t_bool.b) FROM t_bool;
SELECT t_bool.a AND t_bool.b FROM t_bool;

--------------------------------------
-- Elimination
--------------------------------------
(A AND B) OR (A AND NOT B);
(A AND B) OR (A AND NOT B);

(A AND B) OR (NOT A AND B);
(A AND B) OR (B AND NOT A);

(A AND NOT B) OR (A AND B);
(A AND B) OR (A AND NOT B);

(NOT A AND B) OR (A AND B);
(A AND B) OR (B AND NOT A);

(A OR B) AND (A OR NOT B);
(A OR B) AND (A OR NOT B);

(A OR B) AND (NOT A OR B);
(A OR B) AND (B OR NOT A);

(A OR NOT B) AND (A OR B);
(A OR B) AND (A OR NOT B);

(NOT A OR B) AND (A OR B);
(A OR B) AND (B OR NOT A);

(NOT A OR NOT B) AND (NOT A OR B);
(B OR NOT A) AND (NOT A OR NOT B);

(NOT A OR NOT B) AND (NOT A OR NOT NOT B);
(NOT A OR NOT B) AND (NOT A OR NOT NOT B);

E OR (A AND B) OR C OR D OR (A AND NOT B);
(A AND B) OR (A AND NOT B) OR C OR D OR E;

(A AND B) OR (A AND NOT B) OR (A AND NOT B);
(A AND B) OR (A AND NOT B);

(A AND B) OR (A AND B) OR (A AND NOT B);
(A AND B) OR (A AND NOT B);

(A AND B) OR (A AND NOT B) OR (A AND B) OR (A AND NOT B);
(A AND B) OR (A AND NOT B);

(B AND x IS NULL) OR (B AND NOT (x IS NULL));
B AND TRUE;

(B OR x IS NULL) AND (B OR NOT (x IS NULL));
B AND TRUE;

SELECT t_bool.a OR t_bool.a FROM t_bool;
SELECT t_bool.a FROM t_bool;

SELECT t_bool.a AND t_bool.a FROM t_bool;
SELECT t_bool.a FROM t_bool;

# schema: {"t": {"x": "INT"}}
SELECT SUM(t.x OR t.x) FROM t;
SELECT SUM(t.x AND TRUE) FROM t;

# schema: {"t": {"x": "INT"}}
SELECT SUM(t.x AND t.x) FROM t;
SELECT SUM(t.x AND TRUE) FROM t;

# dialect: clickhouse
SELECT (t_bool.a AND t_bool.b) OR (t_bool.a AND NOT t_bool.b) FROM t_bool;
SELECT t_bool.a FROM t_bool;

--------------------------------------
-- Associativity
--------------------------------------
(A AND B) AND C;
A AND B AND C;

A AND (B AND C);
A AND B AND C;

(A OR B) OR C;
A OR B OR C;

A OR (B OR C);
A OR B OR C;

((A AND B) AND C) AND D;
A AND B AND C AND D;

(((((A) AND B)) AND C)) AND D;
A AND B AND C AND D;

(x + 1) + 2;
x + 3;

x + (1 + 2);
x + 3;

(x * 2) * 4 + (1 + 3) + 5;
x * 8 + 9;

(x - 1) - 2;
(x - 1) - 2;

x - (3 - 2);
x - 1;

--------------------------------------
-- Comparison and Pruning
--------------------------------------
A AND D AND B AND E AND F AND G AND E AND A;
A AND B AND D AND E AND F AND G;

A OR D OR B OR E OR F OR G OR E OR A;
A OR B OR D OR E OR F OR G;

# dialect: mysql
A XOR D XOR B XOR E XOR F XOR G XOR C;
A XOR B XOR C XOR D XOR E XOR F XOR G;

A AND NOT B AND C AND B;
A AND B AND C AND NOT B;

(a AND b AND c AND d) AND (d AND c AND b AND a);
a AND b AND c AND d;

(c AND (a AND b)) AND ((b AND a) AND c);
a AND b AND c;

(A AND B AND C) OR (C AND B AND A);
A AND B AND C;

--------------------------------------
-- Where removal
--------------------------------------
SELECT x WHERE TRUE;
SELECT x;

# dialect: duckdb
# execute: true
SELECT COUNT(*) FILTER (WHERE TRUE) FROM x;
SELECT COUNT(*) FILTER(WHERE TRUE) FROM x;

# dialect: duckdb
# execute: true
COUNT(*) FILTER (WHERE 1 = 1);
COUNT(*) FILTER(WHERE TRUE);

# dialect: duckdb
# execute: true
SELECT COUNT(a) FILTER (WHERE TRUE) AS count_value, SUM(DISTINCT a) FILTER (WHERE 1 = 1) AS sum_value FROM x;
SELECT COUNT(a) FILTER(WHERE TRUE) AS count_value, SUM(DISTINCT a) FILTER(WHERE TRUE) AS sum_value FROM x;

# dialect: duckdb
# execute: true
SELECT COUNT(*) FILTER (WHERE TRUE), SUM(a) FILTER (WHERE TRUE) FROM x WHERE FALSE;
SELECT COUNT(*) FILTER(WHERE TRUE), SUM(a) FILTER(WHERE TRUE) FROM x WHERE FALSE;

# dialect: duckdb
# execute: true
SELECT COUNT(*) FILTER (WHERE FALSE) AS count_value, SUM(a) FILTER (WHERE NULL) AS null_sum, SUM(a) FILTER (WHERE a > 1 AND TRUE) AS sum_value FROM x;
SELECT COUNT(*) FILTER(WHERE FALSE) AS count_value, SUM(a) FILTER(WHERE NULL) AS null_sum, SUM(a) FILTER(WHERE a > 1) AS sum_value FROM x;

# dialect: duckdb
# execute: true
SELECT a, SUM(a) FILTER (WHERE TRUE) OVER () FROM x ORDER BY a;
SELECT a, SUM(a) FILTER(WHERE TRUE) OVER () FROM x ORDER BY a;

# dialect: duckdb
# execute: true
SELECT COUNT(*) FILTER (WHERE TRUE) FROM x WHERE TRUE;
SELECT COUNT(*) FILTER(WHERE TRUE) FROM x;

SELECT x FROM y JOIN z ON TRUE;
SELECT x FROM y CROSS JOIN z;

SELECT x FROM y RIGHT JOIN z ON TRUE;
SELECT x FROM y RIGHT JOIN z ON TRUE;

SELECT x FROM y LEFT JOIN z ON TRUE;
SELECT x FROM y LEFT JOIN z ON TRUE;

SELECT x FROM y FULL OUTER JOIN z ON TRUE;
SELECT x FROM y FULL OUTER JOIN z ON TRUE;

SELECT x FROM y JOIN z USING (x);
SELECT x FROM y JOIN z USING (x);

--------------------------------------
-- Parenthesis removal
--------------------------------------
(TRUE);
TRUE;

(FALSE);
FALSE;

((TRUE));
TRUE;

(FALSE OR TRUE);
TRUE;

TRUE OR (((FALSE) OR (TRUE)) OR FALSE);
TRUE;

(NOT FALSE) AND (NOT TRUE);
FALSE;

((NOT FALSE) AND (x = x)) AND (TRUE OR 1 <> 3);
x = x;

((NOT FALSE) AND (x = x)) AND (FALSE OR 1 <> 2);
x = x;

(('a' = 'a') AND TRUE and NOT FALSE);
TRUE;

(x = y) and z;
x = y AND z;

x * (1 - y);
x * (1 - y);

(((x % 20) = 0) = TRUE);
((x % 20) = 0) = TRUE;

ANY(t.value);
ANY(t.value);

SELECT (ARRAY_AGG(foo))[1];
SELECT (ARRAY_AGG(foo))[1];

SELECT -(x.a > x.b) FROM x;
SELECT -(x.a > x.b) FROM x;

SELECT (-((x.a) IS NULL)) FROM x;
SELECT -(x.a IS NULL) FROM x;

# dialect: sqlite
SELECT +(x = 1) FROM t;
SELECT +(x = 1) FROM t;

# dialect: sqlite
SELECT +(x IN (1, 2)) FROM t;
SELECT +(x IN (1, 2)) FROM t;

# dialect: sqlite
SELECT +(x IS 1) FROM t;
SELECT +(x IS 1) FROM t;

# dialect: sqlite
SELECT +(NOT x) FROM t;
SELECT +(NOT x) FROM t;

-- like unary minus, `~` binds tighter than a predicate, so its parens must be kept
# dialect: postgres
~(a = b);
~(a = b);

# dialect: postgres
~(a LIKE b);
~(a LIKE b);

# dialect: postgres
~(a @> b);
~(a @> b);

SELECT * FROM A WHERE a - (b < c) < 0 AND a + (b > c) >= 0;
SELECT * FROM A WHERE a + (b > c) >= 0 AND a - (b < c) < 0;

# dialect: postgres
NOT (a @> b);
NOT a @> b;

# dialect: postgres
NOT (a <@ b);
NOT a <@ b;

# dialect: postgres
NOT (a && b);
NOT a && b;

# dialect: postgres
(j ? 'a') AND id = 1;
j ? 'a' AND id = 1;

# dialect: postgres
(j ?& ARRAY['a']) AND id = 1;
j ?& ARRAY['a'] AND id = 1;

# dialect: postgres
(j ?| ARRAY['a']) AND id = 1;
j ?| ARRAY['a'] AND id = 1;

# dialect: postgres
NOT (s ~ 'a');
NOT s ~ 'a';

# dialect: postgres
NOT (s ~* 'a');
NOT s ~* 'a';

# dialect: postgres
(r1 -|- r2) AND id = 1;
r1 -|- r2 AND id = 1;

# dialect: postgres
(r1 &< r2) AND id = 1;
r1 &< r2 AND id = 1;

# dialect: postgres
(r1 &> r2) AND id = 1;
r1 &> r2 AND id = 1;

-- a predicate parent keeps the parens
# dialect: postgres
(a @> b) = (c @> d);
(a @> b) = (c @> d);

# dialect: duckdb
NOT (REGEXP_MATCHES(s, 'a'));
NOT REGEXP_MATCHES(s, 'a');

# dialect: spark
NOT (s RLIKE 'a');
NOT s RLIKE 'a';


--------------------------------------
-- Literals
--------------------------------------
1 + 1;
2;

0.06 + 0.01;
0.07;

0.06 + 1;
1.06;

1.2E+1 + 15E-3;
12.015;

1.2E1 + 15E-3;
12.015;

1 - 2;
-1;

-1 + 3;
2;

1 - 2 - 4;
-5;

-(-1);
1;

- -+1;
1;

+-1;
-1;

++1;
1;

0.06 - 0.01;
0.05;

3 * 4;
12;

3.0 * 9;
27.0;

0.03 * 0.73;
0.0219;

1 / 3;
1 / 3;

1 / 3.0;
0.3333333333333333333333333333;

20.0 / 6;
3.333333333333333333333333333;

1.0 / 0;
1.0 / 0;

0.0 / 0.0;
0.0 / 0.0;

10 / 5;
10 / 5;

(1.0 * 3) * 4 - 2 * (5 / 2);
12.0 - 2 * (5 / 2);

a * 0.5 / 10 / (2.0 + 3);
a * 0.5 / 10 / 5.0;

a * 0.5 - 10 - (2.0 + 3);
a * 0.5 - 10 - 5.0;

x * (10 - 5);
x * 5;

6 - 2 + 4 * 2 + a;
12 + a;

a + 1 + 1 + 2;
a + 4;

a + (1 + 1) + (10);
a + 12;

a + (1 * 1) + (1 - (1 * 1));
a + 1;

a + (b * c) + (d - (e * f));
a + b * c + (d - e * f);

5 + 4 * 3;
17;

1 < 2;
TRUE;

2 <= 2;
TRUE;

2 >= 2;
TRUE;

2 > 1;
TRUE;

2 > 2.5;
FALSE;

3 > 2.5;
TRUE;

1 > NULL;
1 > NULL;

1 <= NULL;
1 <= NULL;

1 IS NULL;
FALSE;

NULL IS NULL;
TRUE;

NULL IS NOT NULL;
FALSE;

1 IS NOT NULL;
TRUE;

# dialect: postgres
# title: postgres preserves IS NOT NULL, constant folding respects the negation
NULL IS NOT NULL;
FALSE;

# dialect: postgres
'a' IS NOT NULL;
TRUE;

# dialect: postgres
# title: IS NULL and IS NOT NULL are distinct predicates, complement law must not fold them
r IS NULL OR r IS NOT NULL;
r IS NOT NULL OR r IS NULL;

# dialect: postgres
# title: IS NULL and IS NOT NULL are not deduplicated
r IS NULL AND r IS NOT NULL;
r IS NOT NULL AND r IS NULL;

# dialect: postgres
# title: IS NOT NULL next to a comparison must not crash the range simplifier
r IS NOT NULL AND r > 5;
r > 5 AND r IS NOT NULL;

date '1998-12-01' - interval x day;
CAST('1998-12-01' AS DATE) - INTERVAL x DAY;

date '1998-12-01' - interval '90' day;
CAST('1998-09-02' AS DATE);

CAST('2020-01-01' AS DATE) + INTERVAL '3000000.0' DAY;
CAST('2020-01-01' AS DATE) + INTERVAL '3000000.0' DAY;

CAST('2020-01-01' AS DATE) + INTERVAL '10000.0' YEAR;
CAST('2020-01-01' AS DATE) + INTERVAL '10000.0' YEAR;

CAST('2020-01-01' AS DATE) - INTERVAL '2500' YEAR;
CAST('2020-01-01' AS DATE) - INTERVAL '2500' YEAR;

x + INTERVAL '10000.0' YEAR = CAST('2020-01-01' AS DATE);
x + INTERVAL '10000.0' YEAR = CAST('2020-01-01' AS DATE);

date '1998-12-01' + interval '1' week;
CAST('1998-12-08' AS DATE);

interval '1' year + date '1998-01-01';
CAST('1999-01-01' AS DATE);

interval '1' year + date '1998-01-01' + 3 * 7 * 4;
CAST('1999-01-01' AS DATE) + 84;

date '1998-12-01' - interval '90' foo;
CAST('1998-12-01' AS DATE) - INTERVAL '90' FOO;

date '1998-12-01' + interval '90' foo;
CAST('1998-12-01' AS DATE) + INTERVAL '90' FOO;

CAST(x AS DATE) + interval '1' week;
CAST(x AS DATE) + INTERVAL '1' WEEK;

CAST('2008-11-11' AS DATETIME) + INTERVAL '5' MONTH;
CAST('2009-04-11 00:00:00' AS DATETIME);

datetime '1998-12-01' - interval '90' day;
CAST('1998-09-02 00:00:00' AS DATETIME);

CAST(x AS DATETIME) + interval '1' WEEK;
CAST(x AS DATETIME) + INTERVAL '1' WEEK;

# dialect: bigquery
CAST('2023-01-01' AS TIMESTAMP) + INTERVAL 1 DAY;
CAST('2023-01-02 00:00:00' AS TIMESTAMP);

# dialect: bigquery
INTERVAL 1 DAY + CAST('2023-01-01' AS TIMESTAMP);
CAST('2023-01-02 00:00:00' AS TIMESTAMP);

# dialect: bigquery
CAST('2023-01-02' AS TIMESTAMP) - INTERVAL 1 DAY;
CAST('2023-01-01 00:00:00' AS TIMESTAMP);

TS_OR_DS_TO_DATE('1998-12-01 00:00:01') - interval '90' day;
CAST('1998-09-02' AS DATE);

DATE_ADD(CAST('2023-01-02' AS DATE), -2, 'MONTH');
CAST('2022-11-02' AS DATE);

DATE_SUB(CAST('2023-01-02' AS DATE), 1 + 1, 'DAY');
CAST('2022-12-31' AS DATE);

DATE_ADD(CAST('2023-01-02' AS DATETIME), -2, 'HOUR');
CAST('2023-01-01 22:00:00' AS DATETIME);

DATETIME_ADD(CAST('2023-01-02' AS DATETIME), -2, 'HOUR');
CAST('2023-01-01 22:00:00' AS DATETIME);

DATETIME_SUB(CAST('2023-01-02' AS DATETIME), 1 + 1, 'HOUR');
CAST('2023-01-01 22:00:00' AS DATETIME);

DATE_ADD(x, 1, 'MONTH');
DATE_ADD(x, 1, 'MONTH');

DATE_ADD(x, 1);
DATE_ADD(x, 1, 'DAY');

SELECT 1 WHERE 'foo';
SELECT 1 WHERE 'foo';

SELECT 1 WHERE NOT 'foo';
SELECT 1 WHERE NOT 'foo';

--------------------------------------
-- Comparisons
--------------------------------------
x < 0 OR x > 1;
x < 0 OR x > 1;

x < 0 OR x > 0;
x < 0 OR x > 0;

x < 1 OR x > 0;
x < 1 OR x > 0;

x < 1 OR x >= 0;
x < 1 OR x >= 0;

x <= 1 OR x > 0;
x <= 1 OR x > 0;

x <= 1 OR x >= 0;
x <= 1 OR x >= 0;

x <= 1 AND x <= 0;
x <= 0;

x <= 1 AND x > 0;
x <= 1 AND x > 0;

x <= 0 OR x < 0;
x <= 0;

x >= 0 OR x > 0;
x >= 0;

x >= 0 OR x > 1;
x >= 0;

x <= 0 OR x >= 0;
x <= 0 OR x >= 0;

x <= 0 AND x >= 0;
x <= 0 AND x >= 0;

x < 1 AND x < 2;
x < 1;

x < 1 OR x < 2;
x < 2;

x < 2 AND x < 1;
x < 1;

x < 2 OR x < 1;
x < 2;

x < 1 AND x < 1;
x < 1;

x < 1 OR x < 1;
x < 1;

x <= 1 AND x < 1;
x < 1;

x <= 1 OR x < 1;
x <= 1;

x < 1 AND x <= 1;
x < 1;

x < 1 OR x <= 1;
x <= 1;

x > 1 AND x > 2;
x > 2;

x > 1 OR x > 2;
x > 1;

x > 2 AND x > 1;
x > 2;

x > 2 OR x > 1;
x > 1;

x > 1 AND x > 1;
x > 1;

x > 1 OR x > 1;
x > 1;

x >= 1 AND x > 1;
x > 1;

x >= 1 OR x > 1;
x >= 1;

x > 1 AND x >= 1;
x > 1;

x > 1 OR x >= 1;
x >= 1;

x > 1 AND x >= 2;
x >= 2;

x > 1 OR x >= 2;
x > 1;

x > 1 AND x >= 2 AND x > 3 AND x > 0;
x > 3;

(x > 1 AND x >= 2 AND x > 3 AND x > 0) OR x > 0;
x > 0;

x > 1 AND x < 2 AND x > 3;
x < 2 AND x > 3;

x > 1 AND x < 1;
x < 1 AND x > 1;

x < 2 AND x > 1;
x < 2 AND x > 1;

x = 1 AND x < 1;
x < 1 AND x = 1;

x = 1 AND x < 1.1;
x = 1;

x = 1 AND x <= 1;
x = 1;

x = 1 AND x <= 0.9;
x <= 0.9 AND x = 1;

x = 1 AND x > 0.9;
x = 1;

x = 1 AND x > 1;
x = 1 AND x > 1;

x = 1 AND x >= 1;
x = 1;

x = 1 AND x >= 2;
x = 1 AND x >= 2;

x = 1 AND x <> 2;
x = 1;

x <> 1 AND x = 1;
x <> 1 AND x = 1;

x = 1 AND x = 2;
x = 1 AND x = 2;

x <> 1 AND x <> 2 AND x = 1;
x <> 1 AND x = 1;

x <> 1 AND x < 2 AND x < 5;
x < 2 AND x <> 1;

x = 1 OR x = 2 OR x < 0 OR x < 3;
x < 3 OR x = 1 OR x = 2;

SELECT nn.a > 1 AND nn.a < 1 AS r FROM nn;
SELECT FALSE AS r FROM nn;

SELECT nn.a = 1 AND nn.a <> 1 AS r FROM nn;
SELECT FALSE AS r FROM nn;

SELECT nn.a > 1 AND nn.a < 2 AND nn.a > 3 AS r FROM nn;
SELECT FALSE AS r FROM nn;

SELECT nn.a = 1 AND nn.a >= 2 AS r FROM nn;
SELECT FALSE AS r FROM nn;

SELECT nn.a FROM nn WHERE NOT (nn.a < 1 AND nn.a > 3);
SELECT nn.a FROM nn;

SELECT x.a FROM x WHERE NOT (x.a < 1 AND x.a > 3);
SELECT x.a FROM x WHERE x.a <= 3 OR x.a >= 1;

SELECT nn.a, COALESCE(nn.a < 1 AND nn.a > 3, TRUE) AS r FROM nn;
SELECT nn.a, FALSE AS r FROM nn;

SELECT x.a, COALESCE(x.a < 1 AND x.a > 3, TRUE) AS r FROM x;
SELECT x.a, COALESCE(x.a < 1 AND x.a > 3, TRUE) AS r FROM x;

x BETWEEN 0 AND 5 AND x > 3;
x <= 5 AND x > 3;

x > 3 AND 5 > x AND x BETWEEN 0 AND 10;
x < 5 AND x > 3;

x > 3 AND 5 < x AND x BETWEEN 9 AND 10;
x <= 10 AND x >= 9;

NOT x BETWEEN 0 AND 1;
x < 0 OR x > 1;

1 < x AND 3 < x;
x > 3;

'a' < 'b';
TRUE;

x = 2018 OR x <> 2018;
x <> 2018 OR x = 2018;

t0.x = t1.x AND t0.y < t1.y AND t0.y <= t1.y;
t0.x = t1.x AND t0.y < t1.y AND t0.y <= t1.y;

1 < x;
x > 1;

1 <= x;
x >= 1;

1 > x;
x < 1;

1 >= x;
x <= 1;

1 = x;
x = 1;

1 <> x;
x <> 1;

NOT 1 < x;
x <= 1;

NOT 1 <= x;
x < 1;

NOT 1 > x;
x >= 1;

NOT 1 >= x;
x > 1;

NOT 1 = x;
x <> 1;

NOT 1 <> x;
x = 1;

x > CAST('2024-01-01' AS DATE) OR x > CAST('2023-12-31' AS DATE);
x > CAST('2023-12-31' AS DATE);

CAST(x AS DATE) > CAST('2024-01-01' AS DATE) OR CAST(x AS DATE) > CAST('2023-12-31' AS DATE);
CAST(x AS DATE) > CAST('2023-12-31' AS DATE);

FUN() > 0 OR FUN() > 1;
FUN() > 0;

RAND() > 0 OR RAND() > 1;
RAND() > 0 OR RAND() > 1;

CAST(1 AS UINT) >= 0;
TRUE;

CAST(-1 AS TINYINT) <= 0;
TRUE;

CAST(1 AS INT) = CAST(1 AS UINT);
TRUE;

CASE WHEN CAST(1 AS TINYINT) = 1 THEN FALSE ELSE TRUE END;
FALSE;

CAST(1 AS INT) + 1;
CAST(1 AS INT) + 1;

CAST(CAST(CAST(-1 AS INT) AS INT) AS INT) = -1;
TRUE;

CAST(-1 AS UINT) <= 0;
CAST(-1 AS UINT) <= 0;

CAST(-129 AS TINYINT) <= 0;
CAST(-129 AS TINYINT) <= 0;

CAST(256 AS UINT) >= 0;
CAST(256 AS UINT) >= 0;

CAST(CAST(CAST(-1 AS INT) AS UINT) AS INT) = 1;
CAST(CAST(CAST(-1 AS INT) AS UINT) AS INT) = 1;

CAST(x AS TINYINT) = 1;
CAST(x AS TINYINT) = 1;

CAST(CAST(1 AS INT) AS BOOLEAN) = 1;
CAST(CAST(1 AS INT) AS BOOLEAN) = 1;

CAST(CAST(CAST(1 AS INT) AS BOOLEAN) AS INT) = 1;
CAST(CAST(CAST(1 AS INT) AS BOOLEAN) AS INT) = 1;

x > CAST('2023-01-01' AS DATE) AND x < CAST('2023-01-01' AS DATETIME);
x < CAST('2023-01-01' AS DATETIME) AND x > CAST('2023-01-01' AS DATE);

CAST(x AS INT) < 0 AND CAST(x AS INT) >= -500;
CAST(x AS INT) < 0 AND CAST(x AS INT) >= -500;

CAST(x AS INT) < -1 AND CAST(x AS INT) >= -500;
CAST(x AS INT) < -1 AND CAST(x AS INT) >= -500;

CAST(x AS INT) < -500 AND CAST(x AS INT) >= -1;
CAST(x AS INT) < -500 AND CAST(x AS INT) >= -1;

0 > CAST(x AS INT) AND -500 <= CAST(x AS INT);
CAST(x AS INT) < 0 AND CAST(x AS INT) >= -500;

-1 > CAST(x AS INT) AND -500 <= CAST(x AS INT);
CAST(x AS INT) < -1 AND CAST(x AS INT) >= -500;

-500 > CAST(x AS INT) AND -1 <= CAST(x AS INT);
CAST(x AS INT) < -500 AND CAST(x AS INT) >= -1;

CAST(x AS INT) < 1000 AND CAST(x AS INT) >= - -500;
CAST(x AS INT) < 1000 AND CAST(x AS INT) >= 500;

CAST(x AS INT) < 0 AND CAST(x AS INT) >= - - -500;
CAST(x AS INT) < 0 AND CAST(x AS INT) >= -500;

1000 > CAST(x AS INT) AND - -500 <= CAST(x AS INT);
CAST(x AS INT) < 1000 AND CAST(x AS INT) >= 500;

0 > CAST(x AS INT) AND - - -500 <= CAST(x AS INT);
CAST(x AS INT) < 0 AND CAST(x AS INT) >= -500;

--------------------------------------
-- COALESCE
--------------------------------------
# dialect: duckdb
# execute: true
SELECT COALESCE(a, NULL, 1) = 1 AS eq FROM x;
SELECT COALESCE(a, NULL) = 1 OR COALESCE(a, NULL) IS NULL AS eq FROM x;

# dialect: duckdb
# execute: true
SELECT 1 = COALESCE(a, NULL, 1) AS eq FROM x;
SELECT COALESCE(a, NULL) = 1 OR COALESCE(a, NULL) IS NULL AS eq FROM x;

# dialect: duckdb
# execute: true
SELECT 0 < COALESCE(a, NULL, -1) AS gt FROM x;
SELECT COALESCE(a, NULL, -1) > 0 AS gt FROM x;

# dialect: duckdb
# execute: true
SELECT COALESCE(a, NULL, b, 3) = 3 AS eq FROM x;
SELECT COALESCE(a, NULL, b) = 3 OR COALESCE(a, NULL, b) IS NULL AS eq FROM x;

# dialect: duckdb
# execute: true
SELECT COALESCE(a, NULL, NULL, 1) = 1 AS eq FROM x;
SELECT COALESCE(a, NULL, NULL) = 1 OR COALESCE(a, NULL, NULL) IS NULL AS eq FROM x;

# dialect: duckdb
# execute: true
SELECT COALESCE(a, NULL) = 1 AS eq FROM x;
SELECT COALESCE(a, NULL) = 1 AS eq FROM x;

COALESCE(x);
x;

COALESCE(x, 1) = 2;
NOT x IS NULL AND x = 2;

# dialect: redshift
COALESCE(x, 1) = 2;
COALESCE(x, 1) = 2;

2 = COALESCE(x, 1);
NOT x IS NULL AND x = 2;

1 < COALESCE(x, 0);
NOT x IS NULL AND x > 1;

0 >= COALESCE(x, 1);
NOT x IS NULL AND x <= 0;

-1 < COALESCE(x, 0);
x > -1 OR x IS NULL;

1 < COALESCE(x, y, 0);
COALESCE(x, y) > 1 AND NOT COALESCE(x, y) IS NULL;

0 >= COALESCE(x, y, 1);
COALESCE(x, y) <= 0 AND NOT COALESCE(x, y) IS NULL;

1 < COALESCE(x, 0, 5);
NOT x IS NULL AND x > 1;

COALESCE(x, 1, 1) = 1 + 1;
NOT x IS NULL AND x = 2;

COALESCE(x, 1, 2) = 2;
NOT x IS NULL AND x = 2;

COALESCE(x, 3) <= 2;
NOT x IS NULL AND x <= 2;

COALESCE(x, 1) <> 2;
x <> 2 OR x IS NULL;

COALESCE(x, 1) <= 2;
x <= 2 OR x IS NULL;

COALESCE(x, 1) = 1;
x = 1 OR x IS NULL;

COALESCE(x, 1) IS NULL;
FALSE;

COALESCE(ROW() OVER (), 1) = 1;
ROW() OVER () = 1 OR ROW() OVER () IS NULL;

a AND b AND COALESCE(ROW() OVER (), 1) = 1;
(ROW() OVER () = 1 OR ROW() OVER () IS NULL) AND a AND b;

# execute: true
COALESCE(1, 2);
1;

COALESCE(CAST(CAST('2023-01-01' AS TIMESTAMP) AS DATE), x);
CAST(CAST('2023-01-01' AS TIMESTAMP) AS DATE);

COALESCE(CAST(NULL AS DATE), x);
COALESCE(CAST(NULL AS DATE), x);

NOT COALESCE(x, 1) = 2 AND y = 3;
(x <> 2 OR x IS NULL) AND y = 3;

--------------------------------------
-- CONCAT
--------------------------------------
CONCAT(x, y);
CONCAT(x, y);

CONCAT_WS(sep, x, y);
CONCAT_WS(sep, x, y);

CONCAT(x);
CONCAT(x);

CONCAT('a', 'b', 'c');
'abc';

CONCAT('a', NULL);
CONCAT('a', NULL);

CONCAT_WS('-', 'a', 'b', 'c');
'a-b-c';

CONCAT('a', x, y, 'b', 'c');
CONCAT('a', x, y, 'bc');

CONCAT_WS('-', 'a', x, y, 'b', 'c');
CONCAT_WS('-', 'a', x, y, 'b-c');

'a' || 'b';
'ab';

CONCAT_WS('-', 'a');
'a';

CONCAT_WS('-', x, y);
CONCAT_WS('-', x, y);

CONCAT_WS('', x, y);
CONCAT_WS('', x, y);

CONCAT_WS('-', x);
CONCAT_WS('-', x);

CONCAT_WS(sep, 'a', 'b');
CONCAT_WS(sep, 'a', 'b');

'a' || 'b' || x;
'ab' || x;

# schema: {"foo": {"cond": "BOOLEAN"}}
CONCAT(a, b) IN (SELECT * FROM foo WHERE cond);
CONCAT(a, b) IN (SELECT * FROM foo WHERE cond);

--------------------------------------
-- DATE_TRUNC
--------------------------------------
DATE_TRUNC('week', CAST('2023-12-15' AS DATE));
CAST('2023-12-11' AS DATE);

DATE_TRUNC('week', CAST('2023-12-16' AS DATE));
CAST('2023-12-11' AS DATE);

DATE_TRUNC('week', CAST('2023-12-11' AS DATE));
CAST('2023-12-11' AS DATE);

DATE_TRUNC('week', x) > CAST('2023-12-11' AS DATE);
x >= CAST('2023-12-18' AS DATE);

DATE_TRUNC('week', x) = CAST('2023-12-11' AS DATE);
x < CAST('2023-12-18' AS DATE) AND x >= CAST('2023-12-11' AS DATE);

# dialect: bigquery
DATE_TRUNC(CAST('2023-12-15' AS DATE), WEEK);
CAST('2023-12-10' AS DATE);

# dialect: bigquery
DATE_TRUNC(CAST('2023-10-01' AS TIMESTAMP), QUARTER);
CAST('2023-10-01 00:00:00' AS TIMESTAMP);

# dialect: bigquery
DATE_TRUNC(CAST('2023-12-16' AS DATE), WEEK);
CAST('2023-12-10' AS DATE);

# dialect: bigquery
DATE_TRUNC(CAST('2023-12-10' AS DATE), WEEK);
CAST('2023-12-10' AS DATE);

# dialect: bigquery
DATE_TRUNC(x, WEEK) > CAST('2008-11-09' AS DATE);
x >= CAST('2008-11-16' AS DATE);

# dialect: bigquery
DATE_TRUNC(x, WEEK) = CAST('2008-11-09' AS DATE);
x < CAST('2008-11-16' AS DATE) AND x >= CAST('2008-11-09' AS DATE);

# dialect: bigquery
DATE_TRUNC(x, WEEK) <> CAST('2008-11-09' AS DATE);
x < CAST('2008-11-09' AS DATE) OR x >= CAST('2008-11-16' AS DATE);

# dialect: bigquery
DATE_TRUNC(x, WEEK) IN (CAST('2008-11-09' AS DATE), CAST('2008-11-23' AS DATE));
(x < CAST('2008-11-16' AS DATE) AND x >= CAST('2008-11-09' AS DATE)) OR (x < CAST('2008-11-30' AS DATE) AND x >= CAST('2008-11-23' AS DATE));

-- A week start that doesn't match the dialect's week offset must not be simplified
# dialect: bigquery
DATE_TRUNC(CAST('2023-12-15' AS DATE), WEEK(MONDAY));
DATE_TRUNC(CAST('2023-12-15' AS DATE), WEEK(MONDAY));

# dialect: bigquery
DATE_TRUNC(x, WEEK(MONDAY)) = CAST('2008-11-10' AS DATE);
DATE_TRUNC(x, WEEK(MONDAY)) = CAST('2008-11-10' AS DATE);

-- A time zone moves the truncation boundaries, so it must not be simplified
# dialect: bigquery
TIMESTAMP_TRUNC(CAST('2024-02-10 03:00:00+00' AS TIMESTAMP), DAY, 'America/New_York');
TIMESTAMP_TRUNC(CAST('2024-02-10 03:00:00+00' AS TIMESTAMP), DAY, 'America/New_York');

# dialect: bigquery
TIMESTAMP_TRUNC(x, DAY, 'America/New_York') >= CAST('2024-01-01 03:00:00' AS TIMESTAMP);
TIMESTAMP_TRUNC(x, DAY, 'America/New_York') >= CAST('2024-01-01 03:00:00' AS TIMESTAMP);

# dialect: bigquery
TIMESTAMP_TRUNC(x, DAY, 'America/New_York') = CAST('2024-01-01 00:00:00' AS TIMESTAMP);
TIMESTAMP_TRUNC(x, DAY, 'America/New_York') = CAST('2024-01-01 00:00:00' AS TIMESTAMP);

# dialect: bigquery
TIMESTAMP_TRUNC(x, DAY, 'America/New_York') IN (CAST('2024-01-01 00:00:00' AS TIMESTAMP));
TIMESTAMP_TRUNC(x, DAY, 'America/New_York') IN (CAST('2024-01-01 00:00:00' AS TIMESTAMP));

# dialect: postgres
DATE_TRUNC('DAY', x, 'America/New_York') = CAST('2024-01-01 00:00:00' AS TIMESTAMP);
DATE_TRUNC('DAY', x, 'America/New_York') = CAST('2024-01-01 00:00:00' AS TIMESTAMP);

-- T-SQL week truncation follows @@DATEFIRST, which defaults to 7 (Sunday)
# dialect: tsql
DATETRUNC(WEEK, CAST('2021-12-08' AS DATETIME2));
CAST('2021-12-05 00:00:00' AS DATETIME2);

# dialect: tsql
DATETRUNC(WEEK, CAST('2023-12-10' AS DATE));
CAST('2023-12-10' AS DATE);

# dialect: tsql
DATETRUNC(WEEK, x) = CAST('2023-12-10' AS DATE);
x < CAST('2023-12-17' AS DATE) AND x >= CAST('2023-12-10' AS DATE);

# dialect: tsql
DATETRUNC(WEEK, x) > CAST('2023-12-10' AS DATE);
x >= CAST('2023-12-17' AS DATE);

DATE_TRUNC('year', x) = CAST('2021-01-01' AS DATE);
x < CAST('2022-01-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE);

# dialect: bigquery
DATE_TRUNC(x, year) = CAST('2021-01-01' AS TIMESTAMP);
x < CAST('2022-01-01 00:00:00' AS TIMESTAMP) AND x >= CAST('2021-01-01 00:00:00' AS TIMESTAMP);

DATE_TRUNC('quarter', x) = CAST('2021-01-01' AS DATE);
x < CAST('2021-04-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE);

# dialect: bigquery
DATE_TRUNC(x, quarter) = CAST('2021-01-01' AS TIMESTAMP);
x < CAST('2021-04-01 00:00:00' AS TIMESTAMP) AND x >= CAST('2021-01-01 00:00:00' AS TIMESTAMP);

DATE_TRUNC('month', x) = CAST('2021-01-01' AS DATE);
x < CAST('2021-02-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE);

# dialect: bigquery
DATE_TRUNC(x, month) = CAST('2021-01-01' AS TIMESTAMP);
x < CAST('2021-02-01 00:00:00' AS TIMESTAMP) AND x >= CAST('2021-01-01 00:00:00' AS TIMESTAMP);

DATE_TRUNC('week', x) = CAST('2021-01-04' AS DATE);
x < CAST('2021-01-11' AS DATE) AND x >= CAST('2021-01-04' AS DATE);

DATE_TRUNC('day', x) = CAST('2021-01-01' AS DATE);
x < CAST('2021-01-02' AS DATE) AND x >= CAST('2021-01-01' AS DATE);

# dialect: bigquery
DATE_TRUNC(x, DAY) = CAST('2021-01-01' AS TIMESTAMP);
x < CAST('2021-01-02 00:00:00' AS TIMESTAMP) AND x >= CAST('2021-01-01 00:00:00' AS TIMESTAMP);

CAST('2021-01-01' AS DATE) = DATE_TRUNC('year', x);
x < CAST('2022-01-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE);

# dialect: bigquery
CAST('2021-01-01' AS TIMESTAMP) = DATE_TRUNC(x, year);
x < CAST('2022-01-01 00:00:00' AS TIMESTAMP) AND x >= CAST('2021-01-01 00:00:00' AS TIMESTAMP);

-- Always false, except for nulls
DATE_TRUNC('quarter', x) = CAST('2021-01-02' AS DATE);
DATE_TRUNC('QUARTER', x) = CAST('2021-01-02' AS DATE);

DATE_TRUNC('year', x) <> CAST('2021-01-01' AS DATE);
x < CAST('2021-01-01' AS DATE) OR x >= CAST('2022-01-01' AS DATE);

-- the resulting connector must be parenthesized under a different connector or NOT
DATE_TRUNC('year', x) <> CAST('2021-01-01' AS DATE) AND y = 1;
(x < CAST('2021-01-01' AS DATE) OR x >= CAST('2022-01-01' AS DATE)) AND y = 1;

DATE_TRUNC('year', x) = CAST('2021-01-01' AS DATE) OR y = 1;
(x < CAST('2022-01-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE)) OR y = 1;

NOT DATE_TRUNC('year', x) = CAST('2021-01-01' AS DATE);
x < CAST('2021-01-01' AS DATE) OR x >= CAST('2022-01-01' AS DATE);

NOT DATE_TRUNC('year', x) <> CAST('2021-01-01' AS DATE);
x < CAST('2022-01-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE);

-- same as above, but the comparison is reversed and only gets simplified after being sorted
NOT (CAST('2021-01-01' AS DATE) = DATE_TRUNC('year', x));
x < CAST('2021-01-01' AS DATE) OR x >= CAST('2022-01-01' AS DATE);

NOT (CAST('2021-01-01' AS DATE) <> DATE_TRUNC('year', x));
x < CAST('2022-01-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE);

NOT (CAST('2021-01-01' AS DATE) = DATE_TRUNC('year', x)) AND y = 1;
(x < CAST('2021-01-01' AS DATE) OR x >= CAST('2022-01-01' AS DATE)) AND y = 1;

# dialect: bigquery
DATE_TRUNC(x, WEEK) <> CAST('2008-11-09' AS DATE) AND y = 1;
(x < CAST('2008-11-09' AS DATE) OR x >= CAST('2008-11-16' AS DATE)) AND y = 1;

-- Always true, except for nulls
DATE_TRUNC('year', x) <> CAST('2021-01-02' AS DATE);
DATE_TRUNC('YEAR', x) <> CAST('2021-01-02' AS DATE);

DATE_TRUNC('year', x) <= CAST('2021-01-01' AS DATE);
x < CAST('2022-01-01' AS DATE);

# dialect: bigquery
DATE_TRUNC(x, year) <= CAST('2021-01-01' AS TIMESTAMP);
x < CAST('2022-01-01 00:00:00' AS TIMESTAMP);

DATE_TRUNC('year', x) <= CAST('2021-01-02' AS DATE);
x < CAST('2022-01-01' AS DATE);

CAST('2021-01-01' AS DATE) >= DATE_TRUNC('year', x);
x < CAST('2022-01-01' AS DATE);

# dialect: bigquery
CAST('2021-01-01' AS TIMESTAMP) >= DATE_TRUNC(x, year);
x < CAST('2022-01-01 00:00:00' AS TIMESTAMP);

DATE_TRUNC('year', x) < CAST('2021-01-01' AS DATE);
x < CAST('2021-01-01' AS DATE);

DATE_TRUNC('year', x) < CAST('2021-01-02' AS DATE);
x < CAST('2022-01-01' AS DATE);

DATE_TRUNC('year', x) >= CAST('2021-01-01' AS DATE);
x >= CAST('2021-01-01' AS DATE);

DATE_TRUNC('year', x) >= CAST('2021-01-02' AS DATE);
x >= CAST('2022-01-01' AS DATE);

DATE_TRUNC('year', x) > CAST('2021-01-01' AS DATE);
x >= CAST('2022-01-01' AS DATE);

DATE_TRUNC('year', x) > CAST('2021-01-02' AS DATE);
x >= CAST('2022-01-01' AS DATE);

DATE_TRUNC('year', x) > TS_OR_DS_TO_DATE(TS_OR_DS_TO_DATE('2021-01-02'));
x >= CAST('2022-01-01' AS DATE);

DATE_TRUNC('year', x) > TS_OR_DS_TO_DATE(TS_OR_DS_TO_DATE('2021-01-02', '%Y'));
DATE_TRUNC('YEAR', x) > CAST(STR_TO_TIME('2021-01-02', '%Y') AS DATE);

-- right is not a date
DATE_TRUNC('year', x) <> '2021-01-02';
DATE_TRUNC('YEAR', x) <> '2021-01-02';

DATE_TRUNC('year', x) IN (CAST('2021-01-01' AS DATE), CAST('2023-01-01' AS DATE));
(x < CAST('2022-01-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE)) OR (x < CAST('2024-01-01' AS DATE) AND x >= CAST('2023-01-01' AS DATE));

# dialect: bigquery
DATE_TRUNC(x, year) IN (CAST('2021-01-01' AS TIMESTAMP), CAST('2023-01-01' AS TIMESTAMP));
(x < CAST('2022-01-01 00:00:00' AS TIMESTAMP) AND x >= CAST('2021-01-01 00:00:00' AS TIMESTAMP)) OR (x < CAST('2024-01-01 00:00:00' AS TIMESTAMP) AND x >= CAST('2023-01-01 00:00:00' AS TIMESTAMP));

-- merge ranges
DATE_TRUNC('year', x) IN (CAST('2021-01-01' AS DATE), CAST('2022-01-01' AS DATE));
x < CAST('2023-01-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE);

-- one of the values will always be false
DATE_TRUNC('year', x) IN (CAST('2021-01-01' AS DATE), CAST('2022-01-02' AS DATE));
x < CAST('2022-01-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE);

-- the resulting OR must be parenthesized under a tighter-binding parent
DATE_TRUNC('year', x) IN (CAST('2021-01-01' AS DATE), CAST('2023-01-01' AS DATE)) AND y = 1;
((x < CAST('2022-01-01' AS DATE) AND x >= CAST('2021-01-01' AS DATE)) OR (x < CAST('2024-01-01' AS DATE) AND x >= CAST('2023-01-01' AS DATE))) AND y = 1;

NOT DATE_TRUNC('year', x) IN (CAST('2021-01-01' AS DATE), CAST('2023-01-01' AS DATE));
(x < CAST('2021-01-01' AS DATE) OR x >= CAST('2022-01-01' AS DATE)) AND (x < CAST('2023-01-01' AS DATE) OR x >= CAST('2024-01-01' AS DATE));

TIMESTAMP_TRUNC(x, YEAR) = CAST('2021-01-01' AS DATETIME);
x < CAST('2022-01-01 00:00:00' AS DATETIME) AND x >= CAST('2021-01-01 00:00:00' AS DATETIME);

-- right side is not a date literal
DATE_TRUNC('day', x) = CAST(y AS DATE);
CAST(y AS DATE) = DATE_TRUNC('DAY', x);

-- nested cast
DATE_TRUNC('day', x) = CAST(CAST('2021-01-01 01:02:03' AS DATETIME) AS DATE);
x < CAST('2021-01-02' AS DATE) AND x >= CAST('2021-01-01' AS DATE);

TIMESTAMP_TRUNC(x, YEAR) = CAST(CAST('2021-01-01 01:02:03' AS DATE) AS DATETIME);
x < CAST('2022-01-01 00:00:00' AS DATETIME) AND x >= CAST('2021-01-01 00:00:00' AS DATETIME);

DATE_TRUNC('day', CAST(x AS DATE)) <= CAST('2021-01-01 01:02:03' AS TIMESTAMP);
CAST(x AS DATE) < CAST('2021-01-02 00:00:00' AS TIMESTAMP);

--------------------------------------
-- EQUALITY
--------------------------------------
x + 1 = 3;
x = 2;

1 + x = 3;
x = 2;

3 = x + 1;
x = 2;

x - 1 = 3;
x = 4;

x + 1 > 3;
x > 2;

x + 1 >= 3;
x >= 2;

x + 1 <= 3;
x <= 2;

x + 1 <> 3;
x <> 2;

1 + x + 1 = 3 + 1;
x = 2;

0 - a = 1;
a = -1;

5 - x = 2;
x = 3;

5 - x > 2;
x < 3;

5 - x >= 2;
x <= 3;

5 - x < 2;
x > 3;

5 - x <= 2;
x >= 3;

5 - x <> 2;
x <> 3;

1 = 0 - a;
a = -1;

2 > 5 - x;
x > 3;

2 >= 5 - x;
x >= 3;

2 < 5 - x;
x < 3;

2 <= 5 - x;
x <= 3;

2 <> 5 - x;
x <> 3;

x - INTERVAL 1 DAY = CAST('2021-01-01' AS DATE);
x = CAST('2021-01-02' AS DATE);

x - INTERVAL 1 DAY = TS_OR_DS_TO_DATE('2021-01-01 00:00:01');
x = CAST('2021-01-02' AS DATE);

x - INTERVAL 1 HOUR > CAST('2021-01-01' AS DATETIME);
x > CAST('2021-01-01 01:00:00' AS DATETIME);

DATETIME_ADD(x, 1, HOUR) < CAST('2021-01-01' AS DATETIME);
x < CAST('2020-12-31 23:00:00' AS DATETIME);

DATETIME_SUB(x, 1, DAY) >= CAST('2021-01-01' AS DATETIME);
x >= CAST('2021-01-02 00:00:00' AS DATETIME);

DATE_ADD(x, 1, DAY) <= CAST('2021-01-01' AS DATE);
x <= CAST('2020-12-31' AS DATE);

DATE_SUB(x, 1, DAY) <> CAST('2021-01-01' AS DATE);
x <> CAST('2021-01-02' AS DATE);

x + INTERVAL '2' MONTH = CAST('2024-02-29' AS DATE);
x + INTERVAL '2' MONTH = CAST('2024-02-29' AS DATE);

x + INTERVAL '2' MONTH = CAST('2024-04-30' AS DATE);
x + INTERVAL '2' MONTH = CAST('2024-04-30' AS DATE);

x + INTERVAL '2' MONTH = CAST('2024-03-31' AS DATE);
x = CAST('2024-01-31' AS DATE);

x + INTERVAL '1' MONTH = CAST('2024-01-15' AS DATE);
x = CAST('2023-12-15' AS DATE);

x + INTERVAL '2' MONTH > CAST('2024-03-31' AS DATE);
x > CAST('2024-01-31' AS DATE);

x + INTERVAL '2' MONTH > CAST('2024-04-30' AS DATE);
x + INTERVAL '2' MONTH > CAST('2024-04-30' AS DATE);

x + INTERVAL '2' MONTH < CAST('2024-02-29 12:00:00' AS DATETIME);
x + INTERVAL '2' MONTH < CAST('2024-02-29 12:00:00' AS DATETIME);

x - INTERVAL '1' MONTH = CAST('2024-01-31' AS DATE);
x - INTERVAL '1' MONTH = CAST('2024-01-31' AS DATE);

x + INTERVAL '1' YEAR = CAST('2025-02-28' AS DATE);
x + INTERVAL '1' YEAR = CAST('2025-02-28' AS DATE);

x + INTERVAL '1' YEAR = CAST('2025-03-28' AS DATE);
x = CAST('2024-03-28' AS DATE);

x + INTERVAL '1' QUARTER = CAST('2024-02-29' AS DATE);
x + INTERVAL '1' QUARTER = CAST('2024-02-29' AS DATE);

x + INTERVAL '1' QUARTER = CAST('2024-01-15' AS DATE);
x = CAST('2023-10-15' AS DATE);

x + INTERVAL '1' MONTH < CAST('2024-01-15' AS DATE);
x < CAST('2023-12-15' AS DATE);

x + INTERVAL '2' MONTH <= CAST('2024-02-29' AS DATE);
x + INTERVAL '2' MONTH <= CAST('2024-02-29' AS DATE);

x - INTERVAL '2' MONTH >= CAST('2024-01-31' AS DATE);
x >= CAST('2024-03-31' AS DATE);

x + INTERVAL '2' MONTH > CAST('2024-03-31 12:00:00' AS DATETIME);
x > CAST('2024-01-31 12:00:00' AS DATETIME);

DATE_ADD(x, 1, MONTH) < CAST('2024-01-15' AS DATE);
x < CAST('2023-12-15' AS DATE);

x + INTERVAL '1' YEAR < CAST('2025-03-28' AS DATE);
x < CAST('2024-03-28' AS DATE);

x + INTERVAL '1' YEAR >= CAST('2025-02-28' AS DATE);
x + INTERVAL '1' YEAR >= CAST('2025-02-28' AS DATE);

x + INTERVAL '1' QUARTER > CAST('2024-01-15' AS DATE);
x > CAST('2023-10-15' AS DATE);

x - INTERVAL '1' QUARTER <= CAST('2024-02-29' AS DATE);
x - INTERVAL '1' QUARTER <= CAST('2024-02-29' AS DATE);

x + INTERVAL '1' MONTH <> CAST('2024-01-15' AS DATE);
x <> CAST('2023-12-15' AS DATE);

x + INTERVAL '2' MONTH <> CAST('2024-02-29' AS DATE);
x + INTERVAL '2' MONTH <> CAST('2024-02-29' AS DATE);

x - INTERVAL '1' YEAR <> CAST('2024-02-29' AS DATE);
x - INTERVAL '1' YEAR <> CAST('2024-02-29' AS DATE);

DATE_ADD(DATE_ADD(DATE_TRUNC('week', DATE_SUB(x, 1, DAY)), 1, DAY), 1, YEAR) < CAST('2021-01-08' AS DATE);
x < CAST('2020-01-14' AS DATE);

x - INTERVAL '1' day = CAST(y AS DATE);
CAST(y AS DATE) = x - INTERVAL '1' DAY;

--------------------------------------
-- Constant Propagation
--------------------------------------
-- constants only propagate through columns that can't be NULL (nn in the test schema)
SELECT nn.a = 5 AND nn.b = nn.a AS r FROM nn;
SELECT nn.a = 5 AND nn.b = 5 AS r FROM nn;

SELECT nn.a = 5 AND nn.b > nn.a AS r FROM nn;
SELECT nn.a = 5 AND nn.b > 5 AS r FROM nn;

SELECT nn.a = 5 AND nn.a + nn.b = 7 AS r FROM nn;
SELECT nn.a = 5 AND nn.b = 2 AS r FROM nn;

SELECT nn.a = 5 AND nn.a = 6 AS r FROM nn;
SELECT FALSE AS r FROM nn;

x = 5 AND y = x;
x = 5 AND x = y;

5 = x AND y = x;
x = 5 AND x = y;

x = 5 OR y = x;
x = 5 OR x = y;

(x = 5 AND y = x) OR y = 1;
(x = 5 AND x = y) OR y = 1;

t.x = 5 AND y = x;
t.x = 5 AND x = y;

t.x = 'a' AND y = CONCAT_WS('-', t.x, 'b');
t.x = 'a' AND y = CONCAT_WS('-', t.x, 'b');

x = 5 AND y = x AND y + 1 < 5;
x = 5 AND x = y AND y < 4;

x = 5 AND x = 6;
x = 5 AND x = 6;

x = 5 AND (y = x OR z = 1);
x = 5 AND (x = y OR z = 1);

x = 5 AND x + 3 = 8;
x = 5;

# schema: {"t": {"x": "INT", "y": "INT"}}
x = 5 AND (SELECT x FROM t WHERE y = 1);
(SELECT x FROM t WHERE y = 1) AND x = 5;

# schema: {"t": {"y": "INT", "z": "INT"}}
x = 1 AND y > 0 AND (SELECT z = 5 FROM t WHERE y = 1);
(SELECT z = 5 FROM t WHERE y = 1) AND x = 1 AND y > 0;

# schema: {"t": {"a": "BOOLEAN", "b": "BOOLEAN", "c": "BOOLEAN", "z": "INT"}}
x = 1 AND x = y AND (SELECT z FROM t WHERE a AND (b OR c));
(SELECT z FROM t WHERE a AND (b OR c)) AND x = 1 AND x = y;

t1.a = 39 AND t2.b = t1.a AND t3.c = t2.b;
t1.a = 39 AND t1.a = t2.b AND t2.b = t3.c;

x = 1 AND CASE WHEN x = 5 THEN FALSE ELSE TRUE END;
CASE WHEN x = 5 THEN FALSE ELSE TRUE END AND x = 1;

x = 1 AND IF(x = 5, FALSE, TRUE);
CASE WHEN x = 5 THEN FALSE ELSE TRUE END AND x = 1;

x = 1 AND CASE x WHEN 5 THEN FALSE ELSE TRUE END;
CASE WHEN x = 5 THEN FALSE ELSE TRUE END AND x = 1;

x = y AND CASE WHEN x = 5 THEN FALSE ELSE TRUE END;
CASE WHEN x = 5 THEN FALSE ELSE TRUE END AND x = y;

x = 1 AND CASE WHEN y = 5 THEN x = z END;
CASE WHEN y = 5 THEN x = z END AND x = 1;

--------------------------------------
-- Simplify Conditionals
--------------------------------------
IF(TRUE, x, y);
x;

IF(FALSE, x, y);
y;

IF(FALSE, x);
NULL;

IF(NULL, x, y);
y;

IF(cond, x, y);
CASE WHEN cond THEN x ELSE y END;

CASE WHEN TRUE THEN x ELSE y END;
x;

CASE WHEN FALSE THEN x ELSE y END;
y;

CASE WHEN TRUE THEN (SELECT 1) ELSE (SELECT 2) END;
(SELECT 1);

CASE WHEN FALSE THEN (SELECT 1) ELSE (SELECT 2) END;
(SELECT 2);

IF(TRUE, (SELECT 1), (SELECT 2));
(SELECT 1);

IF(FALSE, (SELECT 1), (SELECT 2));
(SELECT 2);

CASE WHEN FALSE THEN x WHEN FALSE THEN y WHEN TRUE THEN z END;
z;

CASE WHEN cond THEN x WHEN TRUE THEN y END;
CASE WHEN cond THEN x ELSE y END;

CASE WHEN cond THEN x WHEN TRUE THEN y WHEN other_cond THEN z ELSE w END;
CASE WHEN cond THEN x ELSE y END;

CASE WHEN FALSE THEN w WHEN cond THEN x WHEN NULL THEN y WHEN other_cond THEN z WHEN TRUE THEN v ELSE u END;
CASE WHEN cond THEN x WHEN other_cond THEN z ELSE v END;

CASE WHEN cond THEN x WHEN 1 + 1 = 2 THEN y ELSE z END;
CASE WHEN cond THEN x ELSE y END;

CASE 1 WHEN x THEN y WHEN 1 THEN z ELSE w END;
CASE WHEN x = 1 THEN y ELSE z END;

# execute: true
SELECT CASE WHEN a > 1 THEN b WHEN TRUE THEN 2 END AS result FROM comparisons;
SELECT CASE WHEN a > 1 THEN b ELSE 2 END AS result FROM comparisons;

# execute: true
SELECT CASE WHEN c THEN a WHEN b = 1 THEN b WHEN TRUE THEN 2 WHEN a = 2 THEN 3 ELSE 4 END AS result FROM comparisons;
SELECT CASE WHEN c THEN a WHEN b = 1 THEN b ELSE 2 END AS result FROM comparisons;

# execute: true
SELECT CASE 1 WHEN a THEN b WHEN 1 THEN 2 ELSE 3 END AS result FROM comparisons;
SELECT CASE WHEN a = 1 THEN b ELSE 2 END AS result FROM comparisons;

CASE NULL WHEN NULL THEN x ELSE y END;
y;

CASE 4 WHEN 1 THEN x WHEN 2 THEN y WHEN 3 THEN z ELSE w END;
w;

CASE 4 WHEN 1 THEN x WHEN 2 THEN y WHEN 3 THEN z WHEN 4 THEN w END;
w;

CASE WHEN value = 1 THEN x ELSE y END;
CASE WHEN value = 1 THEN x ELSE y END;

CASE WHEN FALSE THEN x END;
NULL;

CASE 1 WHEN 1 + 1 THEN x END;
NULL;

CASE WHEN cond THEN x ELSE y END;
CASE WHEN cond THEN x ELSE y END;

CASE WHEN cond THEN x END;
CASE WHEN cond THEN x END;

CASE x WHEN y THEN z ELSE w END;
CASE WHEN x = y THEN z ELSE w END;

CASE x WHEN y THEN z END;
CASE WHEN x = y THEN z END;

CASE x1 + x2 WHEN x3 THEN x4 WHEN x5 + x6 THEN x7 ELSE x8 END;
CASE WHEN x3 = (x1 + x2) THEN x4 WHEN (x1 + x2) = (x5 + x6) THEN x7 ELSE x8 END;

-- collapsing a CASE under an operator must preserve the grouping of the branch
x * CASE WHEN FALSE THEN NULL ELSE a - b END;
x * (a - b);

x * (CASE WHEN 1 IS NULL THEN NULL ELSE 1 - b END);
x * (1 - b);

x - CASE WHEN TRUE THEN a + b ELSE c END;
x - (a + b);

CASE WHEN FALSE THEN NULL ELSE a - b END * x;
(a - b) * x;

x / CASE WHEN FALSE THEN 1 ELSE a * b END;
x / (a * b);

x + CASE WHEN TRUE THEN a * b ELSE c END;
x + a * b;

x * IF(TRUE, a - b, c);
x * (a - b);

x * IF(FALSE, c, a - b);
x * (a - b);

x * CASE WHEN TRUE THEN IF(FALSE, c, a - b) ELSE c END;
x * (a - b);

CASE WHEN TRUE THEN NOT p ELSE FALSE END || 'x';
(NOT p) || 'x';

IF(FALSE, FALSE, NOT p) || 'x';
(NOT p) || 'x';

NOT CASE WHEN TRUE THEN a AND b ELSE c END;
NOT a OR NOT b;

-CASE WHEN TRUE THEN a + b ELSE c END;
-(a + b);

--------------------------------------
-- Simplify STARTSWITH
--------------------------------------
STARTS_WITH('foo', 'f');
TRUE;

STARTS_WITH('foo', 'g');
FALSE;

STARTS_WITH('', 'f');
FALSE;

STARTS_WITH('', '');
TRUE;

STARTS_WITH('foo', '');
TRUE;

STARTS_WITH(NULL, y);
STARTS_WITH(NULL, y);

STARTS_WITH(x, y);
STARTS_WITH(x, y);

STARTS_WITH('x', y);
STARTS_WITH('x', y);

STARTS_WITH(x, 'y');
STARTS_WITH(x, 'y');

--------------------------------------
-- Simplify NOT
--------------------------------------
SELECT NOT(NOT(a)) FROM x;
SELECT NOT NOT a FROM x;

SELECT NOT(NOT(NOT(NOT t_bool.a))) FROM t_bool;
SELECT t_bool.a FROM t_bool;

# dialect: mysql
SELECT NOT(NOT(NOT(NOT t_bool.a))) FROM t_bool;
SELECT NOT NOT NOT NOT t_bool.a FROM t_bool;

# dialect: sqlite
SELECT NOT(NOT(NOT(NOT t_bool.a))) FROM t_bool;
SELECT NOT NOT NOT NOT t_bool.a FROM t_bool;

# dialect: mysql
WITH t0 AS (SELECT 1 AS a, 'foo' AS p) SELECT NOT(NOT(CASE WHEN t0.a > 1 THEN t0.a ELSE t0.p END)) AS res FROM t0;
WITH t0 AS (SELECT 1 AS a, 'foo' AS p) SELECT NOT NOT CASE WHEN t0.a > 1 THEN t0.a ELSE t0.p END AS res FROM t0;

# dialect: sqlite
WITH t0 AS (SELECT 1 AS a, 'foo' AS p) SELECT NOT (NOT(CASE WHEN t0.a > 1 THEN t0.a ELSE t0.p END)) AS res FROM t0;
WITH t0 AS (SELECT 1 AS a, 'foo' AS p) SELECT NOT NOT CASE WHEN t0.a > 1 THEN t0.a ELSE t0.p END AS res FROM t0;

--------------------------------------
-- Simplify complements
--------------------------------------
TRUE OR NOT TRUE;
TRUE;

TRUE AND NOT TRUE;
FALSE;

'a' OR NOT 'a';
TRUE;

'a' AND NOT 'a';
FALSE;

100 OR NOT 100;
TRUE;

100 AND NOT 100;
FALSE;

NULL OR NOT NULL;
NULL AND TRUE;

NULL AND NOT NULL;
NULL AND TRUE;

NULL OR (NULL AND TRUE);
NULL AND TRUE;

SELECT IF(NULL = NULL, 1, 100);
SELECT 100;

# dialect: snowflake
# schema: {"o": {"id": "INT", "observed_date": "DATE"}, "e": {"id": "INT", "metric_date": "DATE"}}
SELECT * FROM o ASOF JOIN e MATCH_CONDITION (o.observed_date >= e.metric_date) ON o.id = e.id;
SELECT * FROM o ASOF JOIN e MATCH_CONDITION (o.observed_date >= e.metric_date) ON e.id = o.id;

# dialect: postgres
NULL = NULL IS NULL;
(NULL = NULL) IS NULL;

# dialect: postgres
FALSE = FALSE IS NULL;
(FALSE = FALSE) IS NULL;

# dialect: postgres
NULL = (NULL IS NULL);
NULL = TRUE;

# dialect: snowflake
NULL = NULL IS NULL;
NULL = TRUE;

# dialect: redshift
NULL = NULL IS NULL;
NULL = TRUE;

# dialect: sqlite
NULL IS NULL BETWEEN 0 AND 0;
0 <= TRUE AND 0 >= TRUE;

# dialect: sqlite
NULL NOT NULL IN (0, 1);
FALSE IN (0, 1);

# dialect: postgres
NULL IS NOT DISTINCT FROM NULL BETWEEN 2 AND 3;
NULL IS NOT DISTINCT FROM (2 <= NULL AND 3 >= NULL);

# dialect: sqlite
a IS b BETWEEN 0 AND 1;
(a IS b) <= 1 AND (a IS b) >= 0;

# dialect: sqlite
a IS DISTINCT FROM b BETWEEN 0 AND 1;
(a IS NOT b) <= 1 AND (a IS NOT b) >= 0;

# dialect: sqlite
a IS NOT DISTINCT FROM b NOT BETWEEN 0 AND 1;
(a IS b) < 0 OR (a IS b) > 1;
